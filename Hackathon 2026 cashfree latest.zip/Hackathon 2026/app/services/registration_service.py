import logging
import secrets
import smtplib
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import List

from fastapi import HTTPException
from pymongo.errors import DuplicateKeyError

from app.database.mongodb import (
    payments_async_collection,
    registrations_async_collection,
    teams_async_collection,
    users_async_collection,
)
from app.models.schemas import StudentRegister, StudentResponse
from config.settings import get_settings

settings = get_settings()
logger = logging.getLogger(__name__)

MAX_TEAM_MEMBERS = 4


def numeric_6() -> str:
    return f"{secrets.randbelow(900000) + 100000:06d}"


async def generate_unique_individual_id() -> str:
    while True:
        candidate = f"SPX_HACK2026_INDV_{numeric_6()}"
        exists = await registrations_async_collection.find_one({"participantId": candidate}, {"_id": 1})
        if not exists:
            return candidate


async def generate_unique_team_base_id() -> str:
    while True:
        candidate = f"SPX_HACK2026_TEAM_{numeric_6()}"
        exists = await teams_async_collection.find_one({"teamId": candidate}, {"_id": 1})
        if not exists:
            return candidate


def send_confirmation_email(recipients: List[str], participant_ids: List[str], registrant_name: str, mode: str) -> None:
    mail_from = settings.mail_from or settings.smtp_user
    if not settings.smtp_host or not settings.smtp_user or not settings.smtp_password or not mail_from:
        return

    plain_body = (
        "Hackathon Registration Confirmation\n\n"
        f"Hello {registrant_name},\n\n"
        "Your registration has been confirmed successfully.\n"
        f"Participation Mode: {mode.title()}\n"
        f"Participant IDs: {', '.join(participant_ids)}\n\n"
        "Event: Spheronix Hackathon 2026\n"
        "Please keep these IDs safe for future communication.\n\n"
        "Regards,\nSpheronix Technologies"
    )

    html_body = f"""
    <html>
      <body>
        <h2>Hackathon Registration Confirmation</h2>
        <p>Hello {registrant_name},</p>
        <p>Your registration has been <strong>confirmed successfully</strong>.</p>
        <p><strong>Participation Mode:</strong> {mode.title()}</p>
        <p><strong>Participant IDs:</strong> {', '.join(participant_ids)}</p>
        <hr />
        <p><em>Event: Spheronix Hackathon 2026</em></p>
        <p>Please keep these IDs safe for future communication.</p>
        <p>Regards,<br/>Spheronix Technologies</p>
      </body>
    </html>
    """

    # Use multipart/alternative: plain text fallback + HTML
    msg = MIMEMultipart("alternative")
    msg["From"] = mail_from
    msg["To"] = ", ".join(recipients)
    msg["Subject"] = "Hackathon Registration Confirmation"
    msg.attach(MIMEText(plain_body, "plain"))
    msg.attach(MIMEText(html_body, "html"))

    with smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=20) as server:
        server.starttls()
        server.login(settings.smtp_user, settings.smtp_password)
        server.sendmail(mail_from, recipients, msg.as_string())


async def register_student(student: StudentRegister, cf_payment_id: str | None) -> StudentResponse:
    duplicate_queries = [
        {"email": student.email},
        {"mobile": student.mobile},
        {"rollNumber": student.rollNumber},
        {"githubProfile": student.githubProfile},
    ]
    for query in duplicate_queries:
        exists = await registrations_async_collection.find_one(query, {"_id": 1})
        if exists:
            raise HTTPException(status_code=400, detail="Duplicate registration data detected.")

    registration_time = datetime.utcnow()
    team_member_ids: List[str] = []

    if student.participationMode == "individual":
        for _ in range(10):
            participant_id = await generate_unique_individual_id()
            doc = student.model_dump()
            doc["participantId"] = participant_id
            doc["teamId"] = None
            doc["registrationDate"] = registration_time
            doc["paymentStatus"] = "success"
            doc["payment_status"] = "success"
            doc["createdAt"] = registration_time
            doc["updatedAt"] = registration_time
            try:
                await registrations_async_collection.insert_one(doc)
                break
            except DuplicateKeyError:
                continue
        else:
            raise HTTPException(status_code=409, detail="Failed to allocate unique participant ID")

        await users_async_collection.update_one(
            {"email": student.email},
            {
                "$set": {"name": student.fullName, "googleId": None, "updatedAt": registration_time},
                "$setOnInsert": {"createdAt": registration_time},
            },
            upsert=True,
        )

        await payments_async_collection.update_one(
            {"cf_order_id": student.cf_order_id},
            {
                "$set": {
                    "participantId": participant_id,
                    "mode": "individual",
                    "amount": student.payment_amount,
                    "order_amount": student.payment_amount,
                    "currency": student.payment_currency,
                    "status": "success",
                    "payment_status": "success",
                    "payment_gateway": "cashfree",
                    "cf_order_id": student.cf_order_id,
                    "cf_payment_id": cf_payment_id,
                    "updatedAt": registration_time,
                },
                "$setOnInsert": {"createdAt": registration_time},
            },
            upsert=True,
        )

        try:
            send_confirmation_email([str(student.email)], [participant_id], student.fullName, "individual")
        except Exception as email_err:
            logger.warning("Failed to send confirmation email: %s", email_err)

        return StudentResponse(
            participantId=participant_id,
            fullName=student.fullName,
            email=str(student.email),
            message="Registration successful! Thank you for registering.",
        )

    if not student.teamMembers or len(student.teamMembers) < 1 or len(student.teamMembers) > MAX_TEAM_MEMBERS:
        raise HTTPException(
            status_code=400,
            detail=f"Team mode requires 1 to {MAX_TEAM_MEMBERS} team members plus 1 leader",
        )

    for _ in range(10):
        team_id = await generate_unique_team_base_id()
        leader_id = f"{team_id}_01"
        existing_leader_id = await registrations_async_collection.find_one({"participantId": leader_id}, {"_id": 1})
        if existing_leader_id:
            continue
        break
    else:
        raise HTTPException(status_code=409, detail="Failed to allocate unique team IDs")

    leader_doc = student.model_dump()
    leader_doc["participantId"] = leader_id
    leader_doc["teamId"] = team_id
    leader_doc["isTeamLeader"] = True
    leader_doc["registrationDate"] = registration_time
    leader_doc["paymentStatus"] = "success"
    leader_doc["payment_status"] = "success"
    leader_doc["createdAt"] = registration_time
    leader_doc["updatedAt"] = registration_time

    member_docs = []
    member_roster = [
        {
            "name": student.fullName,
            "email": str(student.email),
            "mobile": student.mobile,
            "role": "leader",
            "participant_id": leader_id,
        }
    ]

    for index, member in enumerate(student.teamMembers, start=2):
        existing_member = await registrations_async_collection.find_one(
            {"$or": [{"email": str(member.email)}, {"mobile": member.mobile}, {"rollNumber": member.rollNumber}]},
            {"_id": 1},
        )
        if existing_member:
            raise HTTPException(status_code=400, detail=f"Duplicate data for team member {member.fullName}")

        member_id = f"{team_id}_{index:02d}"
        existing_id = await registrations_async_collection.find_one({"participantId": member_id}, {"_id": 1})
        if existing_id:
            raise HTTPException(status_code=409, detail="Team member ID conflict. Please retry payment callback.")
        team_member_ids.append(member_id)

        member_doc = {
            "participantId": member_id,
            "fullName": member.fullName,
            "email": str(member.email),
            "mobile": member.mobile,
            "branch": student.branch,
            "collegeName": student.collegeName,
            "city": student.city,
            "rollNumber": member.rollNumber,
            "githubProfile": member.githubProfile,
            "projectSelected": student.projectSelected,
            "participationMode": "team",
            "teamId": team_id,
            "teamName": student.teamName,
            "isTeamLeader": False,
            "registrationDate": registration_time,
            "createdAt": registration_time,
            "updatedAt": registration_time,
            "paymentStatus": "success",
            "payment_status": "success",
        }
        member_docs.append(member_doc)
        member_roster.append(
            {
                "name": member.fullName,
                "email": str(member.email),
                "mobile": member.mobile,
                "role": "member",
                "participant_id": member_id,
            }
        )

    team_doc = {
        "teamId": team_id,
        "leaderId": leader_id,
        "payment_status": "success",
        "teamName": student.teamName,
        "collegeName": student.collegeName,
        "branch": student.branch,
        "projectSelected": student.projectSelected,
        "members": member_roster,
        "createdAt": registration_time,
        "updatedAt": registration_time,
    }

    try:
        await teams_async_collection.insert_one(team_doc)
        await registrations_async_collection.insert_one(leader_doc)
        await registrations_async_collection.insert_many(member_docs)
    except DuplicateKeyError:
        raise HTTPException(status_code=409, detail="Duplicate team/participant ID conflict. Retry registration.")

    await payments_async_collection.update_one(
        {"cf_order_id": student.cf_order_id},
        {
            "$set": {
                "participantId": leader_id,
                "teamId": team_id,
                "mode": "team",
                "amount": student.payment_amount,
                "order_amount": student.payment_amount,
                "currency": student.payment_currency,
                "status": "success",
                "payment_status": "success",
                "payment_gateway": "cashfree",
                "cf_order_id": student.cf_order_id,
                "cf_payment_id": cf_payment_id,
                "updatedAt": registration_time,
            },
            "$setOnInsert": {"createdAt": registration_time},
        },
        upsert=True,
    )

    await users_async_collection.update_one(
        {"email": student.email},
        {
            "$set": {"name": student.fullName, "googleId": None, "updatedAt": registration_time},
            "$setOnInsert": {"createdAt": registration_time},
        },
        upsert=True,
    )

    recipients = [str(student.email)] + [str(m.email) for m in student.teamMembers]
    all_ids = [leader_id] + team_member_ids
    try:
        send_confirmation_email(recipients, all_ids, student.fullName, "team")
    except Exception as email_err:
        logger.warning("Failed to send team confirmation email: %s", email_err)

    return StudentResponse(
        participantId=leader_id,
        fullName=student.fullName,
        email=str(student.email),
        message="Registration successful! Thank you for registering.",
        teamMemberIds=team_member_ids,
    )
