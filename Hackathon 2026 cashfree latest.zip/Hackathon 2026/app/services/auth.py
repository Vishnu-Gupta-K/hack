from datetime import datetime, timedelta

import jwt
from authlib.jose import jwt as authlib_jwt
from fastapi import Header, HTTPException

from app.database.mongodb import admins_collection
from config.settings import get_settings

settings = get_settings()


def create_jwt_token(username: str, role: str) -> str:
    expiration = datetime.utcnow() + timedelta(hours=settings.jwt_expiration_hours)
    payload = {
        "sub": username,
        "role": role,
        "exp": int(expiration.timestamp()),
        "iat": int(datetime.utcnow().timestamp()),
    }

    if hasattr(jwt, "encode"):
        token = jwt.encode(payload, settings.jwt_secret, algorithm=settings.jwt_algorithm)
        return token.decode("utf-8") if isinstance(token, bytes) else token

    token = authlib_jwt.encode({"alg": settings.jwt_algorithm}, payload, settings.jwt_secret)
    return token.decode("utf-8") if isinstance(token, bytes) else token


def verify_jwt_token(token: str) -> dict:
    if hasattr(jwt, "decode"):
        try:
            return jwt.decode(token, settings.jwt_secret, algorithms=[settings.jwt_algorithm])
        except Exception as exc:
            error_text = str(exc).lower()
            if "expired" in error_text:
                raise HTTPException(status_code=401, detail="Token has expired")
            raise HTTPException(status_code=401, detail="Invalid token")

    try:
        claims = authlib_jwt.decode(token, settings.jwt_secret)
        claims.validate()
        return dict(claims)
    except Exception as exc:
        error_text = str(exc).lower()
        if "expired" in error_text:
            raise HTTPException(status_code=401, detail="Token has expired")
        raise HTTPException(status_code=401, detail="Invalid token")


def get_current_admin(authorization: str = Header(default=None)):
    if not authorization:
        raise HTTPException(status_code=401, detail="Authorization header missing")

    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid authorization format")

    token = authorization.split(" ", 1)[1]
    payload = verify_jwt_token(token)
    admin = admins_collection.find_one({"username": payload["sub"]})
    if not admin:
        raise HTTPException(status_code=401, detail="Admin not found")

    return {
        "username": admin["username"],
        "fullName": admin["fullName"],
        "role": admin["role"],
    }
