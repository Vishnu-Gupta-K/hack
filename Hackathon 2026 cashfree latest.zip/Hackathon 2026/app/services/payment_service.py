import logging
import secrets
from datetime import datetime

from fastapi import HTTPException

from app.database.mongodb import payments_async_collection
from app.models.schemas import PaymentOrderRequest, PaymentOrderResponse
from app.services.cashfree_client import CashfreeAPIError, CashfreeClient
from config.settings import get_settings

settings = get_settings()
logger = logging.getLogger(__name__)

cashfree_client = CashfreeClient(
    app_id=settings.cashfree_app_id,
    secret_key=settings.cashfree_secret_key,
    environment=settings.cashfree_environment,
)


async def verify_cashfree_payment(order_id: str, payment_id: str | None = None) -> dict:
    payment_doc = await payments_async_collection.find_one(
        {"cf_order_id": order_id}, {"_id": 0, "mock_mode": 1, "cf_payment_id": 1}
    )
    if payment_doc and payment_doc.get("mock_mode"):
        mock_payment_id = payment_id or payment_doc.get("cf_payment_id") or f"MOCKPAY_{order_id[-8:]}"
        return {
            "cf_payment_id": mock_payment_id,
            "payment_status": "SUCCESS",
            "mock_mode": True,
        }

    payments_response = await cashfree_client.fetch_order_payments(order_id)
    payments = payments_response if isinstance(payments_response, list) else payments_response.get("payments", [])
    if not payments:
        raise HTTPException(status_code=400, detail="Payment not found for the given order")

    target_payment = None
    for item in payments:
        item_id = item.get("cf_payment_id") or item.get("payment_id") or item.get("paymentId")
        if payment_id and item_id == payment_id:
            target_payment = item
            break

    if target_payment is None:
        target_payment = payments[0]

    status_value = str(target_payment.get("payment_status", "")).upper()
    if status_value != "SUCCESS":
        raise HTTPException(status_code=400, detail=f"Payment is not successful. Current status: {status_value or 'UNKNOWN'}")

    return target_payment


async def create_order(request: PaymentOrderRequest) -> PaymentOrderResponse:
    base_amount = 20
    if request.participationMode == "team":
        total_members = 1 + request.teamMembersCount
        amount = base_amount * total_members
    else:
        amount = base_amount

    cf_order_id = f"CF_{int(datetime.utcnow().timestamp())}_{secrets.token_hex(4)}"
    customer_id = f"cust_{abs(hash(request.email)) % 10_000_000}"

    try:
        order = await cashfree_client.create_order(
            order_id=cf_order_id,
            order_amount=float(amount),
            customer_id=customer_id,
            customer_name=request.fullName,
            customer_email=str(request.email),
            customer_phone=request.mobile,
        )

        await payments_async_collection.update_one(
            {"cf_order_id": cf_order_id},
            {
                "$set": {
                    "cf_order_id": cf_order_id,
                    "payment_gateway": "cashfree",
                    "status": "created",
                    "payment_status": "created",
                    "order_amount": float(amount),
                    "currency": "INR",
                    "email": str(request.email),
                    "fullName": request.fullName,
                    "participationMode": request.participationMode,
                    "mobile": request.mobile,
                    "updatedAt": datetime.utcnow(),
                },
                "$setOnInsert": {"createdAt": datetime.utcnow()},
            },
            upsert=True,
        )

        return PaymentOrderResponse(
            orderId=order["order_id"],
            amount=float(amount),
            currency="INR",
            paymentSessionId=order["payment_session_id"],
            paymentGateway="cashfree",
            environment=settings.cashfree_environment,
        )
    except CashfreeAPIError as exc:
        logger.error("Cashfree order creation failed: %s", exc)
        error_text = str(exc).lower()
        if settings.cashfree_allow_mock_on_block and exc.status_code == 403 and "ip" in error_text and "allow" in error_text:
            mock_order_id = f"MOCK_CF_{int(datetime.utcnow().timestamp())}_{secrets.token_hex(3)}"
            mock_payment_id = f"MOCK_PAY_{secrets.token_hex(6)}"

            await payments_async_collection.update_one(
                {"cf_order_id": mock_order_id},
                {
                    "$set": {
                        "cf_order_id": mock_order_id,
                        "cf_payment_id": mock_payment_id,
                        "payment_gateway": "cashfree",
                        "mock_mode": True,
                        "status": "created",
                        "payment_status": "created",
                        "order_amount": float(amount),
                        "currency": "INR",
                        "email": str(request.email),
                        "fullName": request.fullName,
                        "participationMode": request.participationMode,
                        "mobile": request.mobile,
                        "updatedAt": datetime.utcnow(),
                    },
                    "$setOnInsert": {"createdAt": datetime.utcnow()},
                },
                upsert=True,
            )

            return PaymentOrderResponse(
                orderId=mock_order_id,
                amount=float(amount),
                currency="INR",
                paymentSessionId="MOCK_SESSION",
                paymentGateway="cashfree",
                environment=settings.cashfree_environment,
                mockMode=True,
                mockPaymentId=mock_payment_id,
                message="Cashfree IP allowlist blocked this request. Mock payment mode enabled for local testing.",
            )

        raise HTTPException(status_code=exc.status_code, detail=str(exc))
    except Exception as exc:
        logger.exception("Error creating payment order")
        raise HTTPException(status_code=500, detail=f"Payment Gateway Error: {exc}")
