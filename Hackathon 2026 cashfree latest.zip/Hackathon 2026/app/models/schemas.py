from datetime import datetime
from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, EmailStr, Field, field_validator


class ParticipationMode(str, Enum):
    INDIVIDUAL = "individual"
    TEAM = "team"


class TeamRole(str, Enum):
    LEADER = "leader"
    MEMBER = "member"


class TeamMember(BaseModel):
    participantId: Optional[str] = None
    fullName: str = Field(..., min_length=2, max_length=120)
    email: EmailStr
    mobile: str = Field(..., pattern=r"^\d{10}$")
    rollNumber: str = Field(..., min_length=2, max_length=60)
    githubProfile: str
    collegeName: Optional[str] = None
    branch: Optional[str] = None
    projectSelected: Optional[str] = None
    role: TeamRole = TeamRole.MEMBER

    @field_validator("githubProfile")
    @classmethod
    def validate_github_profile(cls, value: str) -> str:
        if not value.startswith("https://www.github.com/"):
            raise ValueError("GitHub profile must start with https://www.github.com/")
        return value


class StudentRegister(BaseModel):
    participantId: Optional[str] = None
    fullName: str = Field(..., min_length=2, max_length=120)
    email: EmailStr
    mobile: str = Field(..., pattern=r"^\d{10}$")
    branch: str = Field(..., min_length=2, max_length=80)
    collegeName: str = Field(..., min_length=2, max_length=180)
    city: str = Field(..., min_length=2, max_length=80)
    rollNumber: str = Field(..., min_length=2, max_length=60)
    githubProfile: str
    projectSelected: str = Field(..., min_length=2, max_length=120)
    participationMode: ParticipationMode
    registrationDate: datetime = Field(default_factory=datetime.utcnow)
    teamId: Optional[str] = None
    teamName: Optional[str] = None
    isTeamLeader: bool = False
    teamMembers: Optional[List[TeamMember]] = None
    isSelected: Optional[bool] = None
    reviewedBy: Optional[str] = None
    reviewedAt: Optional[datetime] = None
    payment_gateway: Optional[str] = "cashfree"
    cf_payment_id: Optional[str] = None
    cf_order_id: Optional[str] = None
    payment_status: Optional[str] = None
    razorpay_payment_id: Optional[str] = None
    razorpay_order_id: Optional[str] = None
    razorpay_signature: Optional[str] = None
    payment_amount: Optional[float] = None
    payment_currency: Optional[str] = "INR"

    @field_validator("githubProfile")
    @classmethod
    def validate_github_profile(cls, value: str) -> str:
        if not value.startswith("https://www.github.com/"):
            raise ValueError("GitHub profile must start with https://www.github.com/")
        return value

    @field_validator("teamMembers")
    @classmethod
    def validate_team_members(cls, value: Optional[List[TeamMember]]) -> Optional[List[TeamMember]]:
        if value is None:
            return value
        if len(value) > 4:
            raise ValueError("Maximum 4 team members allowed")
        return value


class PaymentOrderRequest(BaseModel):
    participationMode: ParticipationMode
    teamMembersCount: int = Field(default=0, ge=0, le=4)
    email: EmailStr
    fullName: str
    mobile: str = Field(..., pattern=r"^\d{10}$")


class PaymentOrderResponse(BaseModel):
    orderId: str
    amount: float
    currency: str
    paymentSessionId: str
    paymentGateway: str = "cashfree"
    environment: str = "SANDBOX"
    mockMode: bool = False
    mockPaymentId: Optional[str] = None
    message: Optional[str] = None


class PaymentVerification(BaseModel):
    cf_order_id: str
    cf_payment_id: Optional[str] = None


class StudentResponse(BaseModel):
    participantId: str
    fullName: str
    email: str
    message: str
    teamMemberIds: Optional[List[str]] = None


class AdminValidation(BaseModel):
    participantId: str
    isSelected: bool
    reviewedBy: str


class ResultCheck(BaseModel):
    email: EmailStr


class AdminLogin(BaseModel):
    username: str
    password: str


class AdminCreate(BaseModel):
    username: str = Field(..., min_length=3, max_length=50)
    password: str = Field(..., min_length=8)
    fullName: str
    role: str = "admin"


class AdminResponse(BaseModel):
    username: str
    fullName: str
    role: str
    message: str


class CollegeCreate(BaseModel):
    name: str
    city: Optional[str] = ""
    state: Optional[str] = ""


class CollegeResponse(BaseModel):
    name: str
    city: str
    state: str


class DuplicateCheck(BaseModel):
    email: Optional[str] = None
    rollNumber: Optional[str] = None
    githubProfile: Optional[str] = None


class LeaderDetailsResponse(BaseModel):
    teamId: str
    leaderId: str
    collegeName: str
    branch: str
    projectSelected: str


class PaymentSuccessCallback(BaseModel):
    participantId: str
    cf_order_id: str
    cf_payment_id: Optional[str] = None
    payment_status: Optional[str] = None
