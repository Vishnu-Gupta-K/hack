from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, status
from pymongo.errors import DuplicateKeyError

from app.database.mongodb import colleges_async_collection, colleges_collection
from app.models.schemas import CollegeCreate
from app.services.auth import get_current_admin

router = APIRouter(prefix="/api/colleges", tags=["colleges"])


@router.get("")
async def get_colleges():
    colleges = await colleges_async_collection.find({}, {"_id": 0}).sort("name", 1).to_list(length=1000)
    return {"colleges": colleges, "total": len(colleges)}


@router.post("", status_code=status.HTTP_201_CREATED)
def add_college(college: CollegeCreate, current_admin: dict = Depends(get_current_admin)):
    try:
        colleges_collection.insert_one(
            {
                "name": college.name,
                "city": college.city or "",
                "state": college.state or "",
                "addedBy": current_admin["username"],
                "addedAt": datetime.utcnow(),
            }
        )
        return {"message": "College added successfully", "name": college.name}
    except DuplicateKeyError:
        raise HTTPException(status_code=400, detail="College already exists")


@router.delete("/{college_name}")
def delete_college(college_name: str, current_admin: dict = Depends(get_current_admin)):
    if current_admin["role"] != "superadmin":
        raise HTTPException(status_code=403, detail="Only superadmin can delete colleges")

    result = colleges_collection.delete_one({"name": college_name})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="College not found")

    return {"message": f"College '{college_name}' deleted successfully"}
