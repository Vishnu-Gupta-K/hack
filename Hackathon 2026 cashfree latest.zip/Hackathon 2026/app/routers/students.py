from datetime import datetime

from fastapi import APIRouter, HTTPException, status

from app.database.mongodb import payments_async_collection, registrations_async_collection
from app.models.schemas import (
    DuplicateCheck,
    ResultCheck,
    StudentRegister,
    StudentResponse,
)
from app.services.payment_service import verify_cashfree_payment
from app.services.registration_service import register_student as register_student_service

router = APIRouter(tags=["students"])
MAX_TEAM_MEMBERS = 4


@router.get("/api/generate-id")
async def generate_participant_id():
    return {"participantId": "GENERATED_AFTER_PAYMENT"}


@router.get("/api/generate-member-ids/{count}")
async def generate_member_ids(count: int):
    if count < 1 or count > MAX_TEAM_MEMBERS:
        raise HTTPException(status_code=400, detail=f"Count must be between 1 and {MAX_TEAM_MEMBERS}")
    return {"participantIds": [f"GENERATED_AFTER_PAYMENT_{idx:02d}" for idx in range(2, count + 2)]}


@router.get("/api/generate-team-id")
async def generate_team_id():
    return {"teamId": "GENERATED_AFTER_PAYMENT"}


@router.get("/api/check-email/{email}")
async def check_email_exists(email: str):
    existing = await registrations_async_collection.find_one({"email": email}, {"_id": 1})
    return {"exists": existing is not None}


@router.get("/api/check-roll-number/{roll_number}")
async def check_roll_number_exists(roll_number: str):
    existing = await registrations_async_collection.find_one({"rollNumber": roll_number}, {"_id": 1})
    if existing:
        return {"exists": True, "message": "Already exists."}
    return {"exists": False}


@router.get("/api/check-github/{github_profile:path}")
async def check_github_exists(github_profile: str):
    existing = await registrations_async_collection.find_one({"githubProfile": github_profile}, {"_id": 1})
    if existing:
        return {"exists": True, "message": "Already exists."}
    return {"exists": False}


@router.post("/api/check-duplicate")
async def check_duplicate(data: DuplicateCheck):
    checks = []

    if data.email and await registrations_async_collection.find_one({"email": data.email}, {"_id": 1}):
        checks.append({"field": "email", "exists": True, "message": "This email is already registered."})

    if data.rollNumber and await registrations_async_collection.find_one({"rollNumber": data.rollNumber}, {"_id": 1}):
        checks.append({"field": "rollNumber", "exists": True, "message": "Already exists."})

    if data.githubProfile and await registrations_async_collection.find_one(
        {"githubProfile": data.githubProfile}, {"_id": 1}
    ):
        checks.append({"field": "githubProfile", "exists": True, "message": "Already exists."})

    return {"hasDuplicate": len(checks) > 0, "duplicates": checks}


@router.post("/api/register", response_model=StudentResponse, status_code=status.HTTP_201_CREATED)
async def register_student(student: StudentRegister):
    if not student.cf_order_id:
        raise HTTPException(status_code=400, detail="Payment details are missing. Please complete the payment first.")

    try:
        verified_payment = await verify_cashfree_payment(student.cf_order_id, student.cf_payment_id)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Payment verification error: {exc}")

    cf_payment_id = verified_payment.get("cf_payment_id") or verified_payment.get("payment_id") or verified_payment.get("paymentId")

    await payments_async_collection.update_one(
        {"cf_order_id": student.cf_order_id},
        {
            "$set": {
                "cf_order_id": student.cf_order_id,
                "cf_payment_id": cf_payment_id,
                "payment_gateway": "cashfree",
                "status": "success",
                "payment_status": "success",
                "updatedAt": datetime.utcnow(),
            },
            "$setOnInsert": {"createdAt": datetime.utcnow()},
        },
        upsert=True,
    )

    return await register_student_service(student, cf_payment_id)


@router.post("/api/check-result")
async def check_result(data: ResultCheck):
    student = await registrations_async_collection.find_one({"email": data.email})
    if not student:
        raise HTTPException(status_code=404, detail="No registration found with this email.")

    payment_status = (student.get("paymentStatus") or student.get("payment_status") or "").lower()
    status_text = "Verified" if payment_status == "success" else "Not Verified"

    return {
        "participantId": student.get("participantId"),
        "fullName": student.get("fullName"),
        "email": student.get("email"),
        "projectSelected": student.get("projectSelected"),
        "participationMode": student.get("participationMode"),
        "teamName": student.get("teamName"),
        "isSelected": student.get("isSelected"),
        "status": status_text,
    }
