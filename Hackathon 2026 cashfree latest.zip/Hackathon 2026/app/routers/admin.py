import io
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException

from app.database.mongodb import (
    admin_validation_collection,
    admins_collection,
    hash_password,
    students_collection,
    teams_collection,
)
from app.models.schemas import AdminCreate, AdminLogin, AdminResponse, AdminValidation
from app.services.auth import create_jwt_token, get_current_admin

router = APIRouter(prefix="/api/admin", tags=["admin"])


@router.post("/login")
def admin_login(credentials: AdminLogin):
    admin = admins_collection.find_one({"username": credentials.username})
    if not admin or admin["password"] != hash_password(credentials.password):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    token = create_jwt_token(admin["username"], admin["role"])
    return {
        "token": token,
        "admin": {
            "username": admin["username"],
            "fullName": admin["fullName"],
            "role": admin["role"],
        },
        "message": "Login successful",
    }


@router.get("/verify")
def verify_admin_token(current_admin: dict = Depends(get_current_admin)):
    return {"valid": True, "admin": current_admin}


@router.post("/create", response_model=AdminResponse)
def create_admin(admin_data: AdminCreate, current_admin: dict = Depends(get_current_admin)):
    if current_admin["role"] != "superadmin":
        raise HTTPException(status_code=403, detail="Only superadmin can create new admins")

    if admins_collection.find_one({"username": admin_data.username}):
        raise HTTPException(status_code=400, detail="Username already exists")

    admins_collection.insert_one(
        {
            "username": admin_data.username,
            "password": hash_password(admin_data.password),
            "fullName": admin_data.fullName,
            "role": admin_data.role,
            "createdAt": datetime.utcnow(),
            "createdBy": current_admin["username"],
        }
    )

    return AdminResponse(
        username=admin_data.username,
        fullName=admin_data.fullName,
        role=admin_data.role,
        message="Admin created successfully",
    )


@router.get("/list")
def list_admins(current_admin: dict = Depends(get_current_admin)):
    if current_admin["role"] != "superadmin":
        raise HTTPException(status_code=403, detail="Unauthorized")

    admins = list(admins_collection.find({}, {"_id": 0, "password": 0}))
    return {"admins": admins, "total": len(admins)}


@router.delete("/delete/{username}")
def delete_admin(username: str, current_admin: dict = Depends(get_current_admin)):
    if current_admin["role"] != "superadmin":
        raise HTTPException(status_code=403, detail="Unauthorized")
    if username == "admin":
        raise HTTPException(status_code=400, detail="Cannot delete the default admin")
    if username == current_admin["username"]:
        raise HTTPException(status_code=400, detail="Cannot delete yourself")

    result = admins_collection.delete_one({"username": username})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Admin not found")

    return {"message": f"Admin '{username}' deleted successfully"}


@router.get("/students")
def get_all_students(skip: int = 0, limit: int = 100, current_admin: dict = Depends(get_current_admin)):
    students = list(students_collection.find({}, {"_id": 0}).skip(skip).limit(limit))
    total = students_collection.count_documents({})
    return {"students": students, "total": total}


@router.get("/teams")
def get_all_teams(current_admin: dict = Depends(get_current_admin)):
    teams = list(teams_collection.find({}, {"_id": 0}))
    return {"teams": teams, "total": len(teams)}


@router.put("/validate")
def validate_student(validation: AdminValidation, current_admin: dict = Depends(get_current_admin)):
    result = students_collection.update_one(
        {"participantId": validation.participantId},
        {
            "$set": {
                "isSelected": validation.isSelected,
                "reviewedBy": validation.reviewedBy,
                "reviewedAt": datetime.utcnow(),
            }
        },
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Student not found.")

    admin_validation_collection.insert_one(
        {
            "participantId": validation.participantId,
            "isSelected": validation.isSelected,
            "reviewedBy": validation.reviewedBy,
            "adminUser": current_admin["username"],
            "timestamp": datetime.utcnow(),
        }
    )
    return {"message": "Validation updated successfully."}


@router.get("/export-excel")
def export_to_excel(current_admin: dict = Depends(get_current_admin)):
    try:
        import pandas as pd
        from fastapi.responses import StreamingResponse

        students = list(students_collection.find({}, {"_id": 0}))
        if not students:
            raise HTTPException(status_code=404, detail="No data to export.")

        df = pd.DataFrame(students)
        rename_map = {
            "participantId": "Participant ID",
            "fullName": "Full Name",
            "email": "Email",
            "mobile": "Mobile",
            "branch": "Branch",
            "collegeName": "College",
            "city": "City",
            "rollNumber": "Roll Number",
            "githubProfile": "GitHub Profile",
            "projectSelected": "Project",
            "participationMode": "Mode",
            "registrationDate": "Registration Date",
            "payment_gateway": "Payment Gateway",
            "cf_payment_id": "Cashfree Payment ID",
            "cf_order_id": "Cashfree Order ID",
            "payment_status": "Payment Status",
            "order_amount": "Order Amount (INR)",
            "payment_amount": "Amount (INR)",
            "payment_currency": "Currency",
            "isSelected": "Selected",
            "reviewedBy": "Reviewed By",
        }
        df.rename(columns=rename_map, inplace=True)

        output = io.BytesIO()
        with pd.ExcelWriter(output, engine="openpyxl") as writer:
            df.to_excel(writer, index=False, sheet_name="Registrations")
        output.seek(0)

        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": "attachment; filename=hackathon_registrations.xlsx"},
        )
    except ImportError:
        raise HTTPException(status_code=500, detail="pandas or openpyxl not installed. Run: pip install pandas openpyxl")


@router.get("/stats")
def get_stats(current_admin: dict = Depends(get_current_admin)):
    total_registrations = students_collection.count_documents({})
    individual_count = students_collection.count_documents({"participationMode": "individual"})
    team_leader_count = students_collection.count_documents({"participationMode": "team"})
    total_teams = teams_collection.count_documents({})
    selected_count = students_collection.count_documents({"isSelected": True})
    pending_count = students_collection.count_documents({"isSelected": None})

    team_members_count = 0
    teams = teams_collection.find({})
    for team in teams:
        team_members_count += len(team.get("members", []))

    total_users = individual_count + team_leader_count + team_members_count
    project_stats = list(students_collection.aggregate([{"$group": {"_id": "$projectSelected", "count": {"$sum": 1}}}]))

    return {
        "totalRegistrations": total_registrations,
        "individualParticipants": individual_count,
        "teamLeaders": team_leader_count,
        "teamMembersCount": team_members_count,
        "totalTeams": total_teams,
        "totalUsers": total_users,
        "selectedCount": selected_count,
        "pendingReview": pending_count,
        "projectDistribution": project_stats,
    }


@router.get("/teams-detailed")
def get_teams_detailed(current_admin: dict = Depends(get_current_admin)):
    teams = list(teams_collection.find({}, {"_id": 0}))

    detailed_teams = []
    for team in teams:
        leader = students_collection.find_one({"participantId": team.get("leaderId")}, {"_id": 0})
        detailed_teams.append(
            {
                "teamId": team.get("teamId"),
                "teamName": team.get("teamName"),
                "collegeName": team.get("collegeName"),
                "branch": team.get("branch"),
                "city": team.get("city"),
                "projectSelected": team.get("projectSelected"),
                "totalMembers": team.get("totalMembers", len(team.get("members", [])) + 1),
                "createdAt": team.get("createdAt"),
                "leader": {
                    "participantId": team.get("leaderId"),
                    "fullName": leader.get("fullName") if leader else team.get("leaderName", ""),
                    "email": team.get("leaderEmail"),
                    "mobile": leader.get("mobile") if leader else "",
                    "rollNumber": leader.get("rollNumber") if leader else "",
                    "githubProfile": leader.get("githubProfile") if leader else "",
                    "isSelected": leader.get("isSelected") if leader else None,
                },
                "members": team.get("members", []),
            }
        )

    return {"teams": detailed_teams, "total": len(detailed_teams)}
