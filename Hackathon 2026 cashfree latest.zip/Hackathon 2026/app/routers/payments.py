from datetime import datetime

from fastapi import APIRouter, Header, HTTPException, Request

from app.database.mongodb import payments_async_collection, registrations_async_collection
from app.models.schemas import PaymentOrderRequest, PaymentSuccessCallback, PaymentVerification
from app.services.payment_service import cashfree_client, create_order, verify_cashfree_payment

router = APIRouter(prefix="/api/payment", tags=["payments"])


@router.post("/order")
async def create_payment_order(request: PaymentOrderRequest):
    return await create_order(request)


@router.post("/verify")
async def verify_payment(data: PaymentVerification):
    try:
        verified_payment = await verify_cashfree_payment(data.cf_order_id, data.cf_payment_id)
        cf_payment_id = (
            verified_payment.get("cf_payment_id")
            or verified_payment.get("payment_id")
            or verified_payment.get("paymentId")
        )
        payment_status = str(verified_payment.get("payment_status", "SUCCESS")).lower()

        await payments_async_collection.update_one(
            {"cf_order_id": data.cf_order_id},
            {
                "$set": {
                    "cf_order_id": data.cf_order_id,
                    "cf_payment_id": cf_payment_id,
                    "payment_gateway": "cashfree",
                    "status": "verified",
                    "payment_status": payment_status,
                    "verifiedAt": datetime.utcnow(),
                    "updatedAt": datetime.utcnow(),
                },
                "$setOnInsert": {"createdAt": datetime.utcnow()},
            },
            upsert=True,
        )

        return {
            "status": "success",
            "message": "Payment verified successfully",
            "cf_order_id": data.cf_order_id,
            "cf_payment_id": cf_payment_id,
        }
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Payment verification error: {exc}")


@router.post("/success-callback")
async def payment_success_callback(data: PaymentSuccessCallback):
    try:
        verified_payment = await verify_cashfree_payment(data.cf_order_id, data.cf_payment_id)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Callback verification failed: {exc}")

    cf_payment_id = (
        verified_payment.get("cf_payment_id")
        or verified_payment.get("payment_id")
        or verified_payment.get("paymentId")
    )

    registration = await registrations_async_collection.find_one({"participantId": data.participantId})
    if not registration:
        raise HTTPException(status_code=404, detail="Registration not found")

    await registrations_async_collection.update_one(
        {"participantId": data.participantId},
        {
            "$set": {
                "paymentStatus": "paid",
                "payment_status": "paid",
                "payment_gateway": "cashfree",
                "cf_order_id": data.cf_order_id,
                "cf_payment_id": cf_payment_id,
                "updatedAt": datetime.utcnow(),
            }
        },
    )

    await payments_async_collection.update_one(
        {"cf_order_id": data.cf_order_id},
        {
            "$set": {
                "participantId": data.participantId,
                "payment_gateway": "cashfree",
                "cf_order_id": data.cf_order_id,
                "cf_payment_id": cf_payment_id,
                "status": "paid",
                "payment_status": "paid",
                "updatedAt": datetime.utcnow(),
            },
            "$setOnInsert": {"createdAt": datetime.utcnow()},
        },
        upsert=True,
    )

    return {"status": "success", "message": "Payment callback handled"}


@router.post("/webhook")
async def cashfree_webhook(
    request: Request,
    x_webhook_signature: str | None = Header(default=None, alias="x-webhook-signature"),
):
    raw_body = await request.body()
    if not x_webhook_signature or not cashfree_client.verify_webhook_signature(raw_body, x_webhook_signature):
        raise HTTPException(status_code=400, detail="Invalid webhook signature")

    payload = await request.json()
    data = payload.get("data", {})
    order_data = data.get("order", {})
    payment_data = data.get("payment", {})

    cf_order_id = order_data.get("order_id") or payment_data.get("order_id")
    cf_payment_id = payment_data.get("cf_payment_id") or payment_data.get("payment_id")
    payment_status = str(payment_data.get("payment_status") or payload.get("type") or "").lower()

    if not cf_order_id:
        return {"status": "ignored", "message": "Webhook does not contain order ID"}

    await payments_async_collection.update_one(
        {"cf_order_id": cf_order_id},
        {
            "$set": {
                "payment_gateway": "cashfree",
                "cf_order_id": cf_order_id,
                "cf_payment_id": cf_payment_id,
                "status": payment_status or "updated",
                "payment_status": payment_status or "updated",
                "webhookPayload": payload,
                "updatedAt": datetime.utcnow(),
            },
            "$setOnInsert": {"createdAt": datetime.utcnow()},
        },
        upsert=True,
    )

    return {"status": "success"}
