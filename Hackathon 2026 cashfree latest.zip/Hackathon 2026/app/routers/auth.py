from datetime import datetime

from authlib.integrations.starlette_client import OAuth
from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse

from app.database.mongodb import registrations_async_collection, users_async_collection
from config.settings import get_settings

settings = get_settings()
router = APIRouter(prefix="/api/auth", tags=["auth"])


def safe_js_text(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"').replace("\n", " ")


oauth = OAuth()
oauth.register(
    name="google",
    client_id=settings.google_client_id,
    client_secret=settings.google_client_secret,
    server_metadata_url="https://accounts.google.com/.well-known/openid-configuration",
    client_kwargs={"scope": "openid email profile"},
)


@router.get("/login")
async def login_via_google(request: Request):
    if settings.google_redirect_uri:
        redirect_uri = settings.google_redirect_uri
    else:
        base = str(request.base_url).rstrip("/")
        redirect_path = request.app.url_path_for("auth_callback")
        redirect_uri = f"{base}{redirect_path}"
    return await oauth.google.authorize_redirect(request, redirect_uri)


@router.get("/callback", name="auth_callback")
async def auth_callback(request: Request):
    try:
        token = await oauth.google.authorize_access_token(request)
        user_info = token.get("userinfo")
        if not user_info:
            user_info = await oauth.google.userinfo(token=token)

        email = user_info.get("email")
        name = user_info.get("name", "")
        google_id = user_info.get("sub")

        if not email:
            raise HTTPException(status_code=400, detail="Google account email not available")

        await users_async_collection.update_one(
            {"email": email},
            {
                "$set": {
                    "email": email,
                    "name": name,
                    "googleId": google_id,
                    "lastLoginAt": datetime.utcnow(),
                },
                "$setOnInsert": {"createdAt": datetime.utcnow()},
            },
            upsert=True,
        )

        existing = await registrations_async_collection.find_one({"email": email}, {"_id": 1})
        already_registered = existing is not None

        return HTMLResponse(
            f"""
            <script>
                window.opener.postMessage({{
                    \"status\": \"success\",
                    \"email\": \"{safe_js_text(email)}\",
                    \"name\": \"{safe_js_text(name)}\",
                    \"google_id\": \"{safe_js_text(google_id or '')}\",
                    \"alreadyRegistered\": {"true" if already_registered else "false"}
                }}, \"*\");
                window.close();
            </script>
            """
        )
    except Exception as exc:
        return HTMLResponse(
            f"""
            <script>
                window.opener.postMessage({{
                    \"status\": \"failed\",
                    \"error\": \"{safe_js_text(str(exc))}\"
                }}, \"*\");
                window.close();
            </script>
            """
        )
