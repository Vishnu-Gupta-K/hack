from functools import lru_cache
from typing import List

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    app_name: str = "Spheronix Hackathon Registration API"
    app_env: str = Field(default="development", alias="APP_ENV")
    server_host: str = Field(default="0.0.0.0", alias="SERVER_HOST")
    server_port: int = Field(default=8000, alias="SERVER_PORT")

    mongodb_uri: str = Field(default="mongodb://localhost:27017", alias="MONGODB_URI")
    mongodb_uri_legacy: str = Field(default="", alias="MONGO_URI")
    database_name: str = Field(default="hackathon_db", alias="DATABASE_NAME")
    database_name_legacy: str = Field(default="", alias="DB_NAME")

    cors_origins: str = Field(default="http://localhost:8000,http://127.0.0.1:8000", alias="CORS_ORIGINS")

    secret_key: str = Field(default="change-this-secret", alias="SECRET_KEY")
    jwt_secret: str = Field(default="change-this-jwt-secret", alias="JWT_SECRET")
    jwt_algorithm: str = "HS256"
    jwt_expiration_hours: int = 24

    google_client_id: str = Field(default="", alias="GOOGLE_CLIENT_ID")
    google_client_secret: str = Field(default="", alias="GOOGLE_CLIENT_SECRET")
    google_redirect_uri: str = Field(default="", alias="GOOGLE_REDIRECT_URI")

    cashfree_app_id: str = Field(default="", alias="CASHFREE_APP_ID")
    cashfree_secret_key: str = Field(default="", alias="CASHFREE_SECRET_KEY")
    cashfree_environment: str = Field(default="SANDBOX", alias="CASHFREE_ENVIRONMENT")
    cashfree_allow_mock_on_block: bool = Field(default=False, alias="CASHFREE_ALLOW_MOCK_ON_BLOCK")

    smtp_host: str = Field(default="", alias="SMTP_HOST")
    smtp_port: int = Field(default=587, alias="SMTP_PORT")
    smtp_user: str = Field(default="", alias="SMTP_USER")
    smtp_password: str = Field(default="", alias="SMTP_PASSWORD")
    mail_from: str = Field(default="", alias="MAIL_FROM")

    @property
    def effective_mongodb_uri(self) -> str:
        return self.mongodb_uri_legacy or self.mongodb_uri

    @property
    def effective_database_name(self) -> str:
        return self.database_name_legacy or self.database_name

    @property
    def cors_origin_list(self) -> List[str]:
        return [origin.strip() for origin in self.cors_origins.split(",") if origin.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
