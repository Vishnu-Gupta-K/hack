from fastapi import FastAPI, HTTPException, status, Request, Depends, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse, HTMLResponse, StreamingResponse
from backend.models import StudentRegister, StudentResponse, AdminValidation, ResultCheck, TeamMember, AdminLogin, AdminCreate, AdminResponse, CollegeCreate, CollegeResponse, DuplicateCheck, PaymentOrderRequest, PaymentOrderResponse, PaymentVerification, LeaderDetailsResponse, PaymentSuccessCallback
from backend.cashfree_integration import CashfreeClient, CashfreeAPIError
from backend.database import (
    students_collection,
    teams_collection,
    admin_validation_collection,
    admins_collection,
    colleges_collection,
    hash_password,
    users_async_collection,
    registrations_async_collection,
    teams_async_collection,
    payments_async_collection,
    colleges_async_collection,
    initialize_async_collections,
)
from authlib.integrations.starlette_client import OAuth
from authlib.jose import jwt as authlib_jwt
from starlette.middleware.sessions import SessionMiddleware
from pymongo.errors import DuplicateKeyError
import uvicorn
import os
import io
import jwt
import secrets
import smtplib
import logging
from datetime import datetime, timedelta
from dotenv import load_dotenv
from typing import List
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from contextlib import asynccontextmanager

load_dotenv()

@asynccontextmanager
async def lifespan(_: FastAPI):
    await initialize_async_collections()
    yield


app = FastAPI(title="Spheronix Hackathon Registration API", lifespan=lifespan)
logger = logging.getLogger(__name__)

# --- Security Config ---
SECRET_KEY = os.getenv("SECRET_KEY", "s3cr3t_k3y_for_dev_only_change_in_prod")
JWT_SECRET = os.getenv("JWT_SECRET", secrets.token_hex(32))
JWT_ALGORITHM = "HS256"
JWT_EXPIRATION_HOURS = 24

# --- Cashfree Config ---
CASHFREE_APP_ID = os.getenv("CASHFREE_APP_ID", "")
CASHFREE_SECRET_KEY = os.getenv("CASHFREE_SECRET_KEY", "")
CASHFREE_ENVIRONMENT = os.getenv("CASHFREE_ENVIRONMENT", "SANDBOX")
CASHFREE_ALLOW_MOCK_ON_BLOCK = os.getenv("CASHFREE_ALLOW_MOCK_ON_BLOCK", "false").strip().lower() in {"1", "true", "yes", "on"}
GOOGLE_REDIRECT_URI = os.getenv("GOOGLE_REDIRECT_URI", "").strip()
SMTP_HOST = os.getenv("SMTP_HOST", "")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER = os.getenv("SMTP_USER", "")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
MAIL_FROM = os.getenv("MAIL_FROM", SMTP_USER)

cashfree_client = CashfreeClient(
    app_id=CASHFREE_APP_ID,
    secret_key=CASHFREE_SECRET_KEY,
    environment=CASHFREE_ENVIRONMENT,
)

# Maximum team size (1 leader + 4 members)
MAX_TEAM_SIZE = 5
MAX_TEAM_MEMBERS = 4

def _numeric_6() -> str:
    return f"{secrets.randbelow(900000) + 100000:06d}"


async def generate_unique_participant_id(prefix: str) -> str:
    # Retained for backward compatibility with existing callers.
    while True:
        random_part = _numeric_6()
        candidate = f"{prefix}{random_part}"
        exists = await registrations_async_collection.find_one({"participantId": candidate}, {"_id": 1})
        if not exists:
            return candidate


async def generate_unique_individual_id() -> str:
    while True:
        candidate = f"SPX_HACK2026_INDV_{_numeric_6()}"
        exists = await registrations_async_collection.find_one({"participantId": candidate}, {"_id": 1})
        if not exists:
            return candidate


async def generate_unique_team_base_id() -> str:
    while True:
        candidate = f"SPX_HACK2026_TEAM_{_numeric_6()}"
        exists = await teams_async_collection.find_one({"teamId": candidate}, {"_id": 1})
        if not exists:
            return candidate


def _safe_js_text(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"').replace("\n", " ")


def send_confirmation_email(recipients: List[str], participant_ids: List[str], registrant_name: str, mode: str) -> None:
    if not SMTP_HOST or not SMTP_USER or not SMTP_PASSWORD or not MAIL_FROM:
        # Email delivery is optional in local/dev setups.
        return

    body = (
        "Hackathon Registration Confirmation\n\n"
        f"Hello {registrant_name},\n\n"
        "Your registration has been confirmed successfully.\n"
        f"Participation Mode: {mode.title()}\n"
        f"Participant IDs: {', '.join(participant_ids)}\n\n"
        "Event: Spheronix Hackathon 2026\n"
        "Please keep these IDs safe for future communication.\n\n"
        "Regards,\nSpheronix Technologies"
    )

    msg = MIMEMultipart()
    msg["From"] = MAIL_FROM
    msg["To"] = ", ".join(recipients)
    msg["Subject"] = "Hackathon Registration Confirmation"
    msg.attach(MIMEText(body, "plain"))

    with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=20) as server:
        server.starttls()
        server.login(SMTP_USER, SMTP_PASSWORD)
        server.sendmail(MAIL_FROM, recipients, msg.as_string())


async def verify_cashfree_payment(order_id: str, payment_id: str | None = None) -> dict:
    """Verify payment status directly with Cashfree before trusting client input."""
    payment_doc = await payments_async_collection.find_one({"cf_order_id": order_id}, {"_id": 0, "mock_mode": 1, "cf_payment_id": 1})
    if payment_doc and payment_doc.get("mock_mode"):
        mock_payment_id = payment_id or payment_doc.get("cf_payment_id") or f"MOCKPAY_{order_id[-8:]}"
        return {
            "cf_payment_id": mock_payment_id,
            "payment_status": "SUCCESS",
            "mock_mode": True,
        }

    payments_response = await cashfree_client.fetch_order_payments(order_id)
    payments = payments_response if isinstance(payments_response, list) else payments_response.get("payments", [])

    if not payments:
        raise HTTPException(status_code=400, detail="Payment not found for the given order")

    target_payment = None
    for item in payments:
        item_id = item.get("cf_payment_id") or item.get("payment_id") or item.get("paymentId")
        if payment_id and item_id == payment_id:
            target_payment = item
            break

    if target_payment is None:
        target_payment = payments[0]

    status_value = str(target_payment.get("payment_status", "")).upper()
    if status_value != "SUCCESS":
        raise HTTPException(status_code=400, detail=f"Payment is not successful. Current status: {status_value or 'UNKNOWN'}")

    return target_payment

app.add_middleware(SessionMiddleware, secret_key=SECRET_KEY)

# --- Google OAuth Setup ---
oauth = OAuth()
oauth.register(
    name='google',
    client_id=os.getenv("GOOGLE_CLIENT_ID"),
    client_secret=os.getenv("GOOGLE_CLIENT_SECRET"),
    server_metadata_url='https://accounts.google.com/.well-known/openid-configuration',
    client_kwargs={'scope': 'openid email profile'}
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ========================
# JWT AUTHENTICATION
# ========================

def create_jwt_token(username: str, role: str) -> str:
    """Create JWT token for admin authentication"""
    expiration = datetime.utcnow() + timedelta(hours=JWT_EXPIRATION_HOURS)
    payload = {
        "sub": username,
        "role": role,
        "exp": int(expiration.timestamp()),
        "iat": int(datetime.utcnow().timestamp()),
    }

    # Prefer PyJWT if available, else fallback to Authlib JWT implementation.
    if hasattr(jwt, "encode"):
        token = jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)
        return token.decode("utf-8") if isinstance(token, bytes) else token

    token = authlib_jwt.encode({"alg": JWT_ALGORITHM}, payload, JWT_SECRET)
    return token.decode("utf-8") if isinstance(token, bytes) else token

def verify_jwt_token(token: str) -> dict:
    """Verify JWT token and return payload"""
    if hasattr(jwt, "decode"):
        try:
            return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        except Exception as exc:
            error_text = str(exc).lower()
            if "expired" in error_text:
                raise HTTPException(status_code=401, detail="Token has expired")
            raise HTTPException(status_code=401, detail="Invalid token")

    try:
        claims = authlib_jwt.decode(token, JWT_SECRET)
        claims.validate()
        return dict(claims)
    except Exception as exc:
        error_text = str(exc).lower()
        if "expired" in error_text:
            raise HTTPException(status_code=401, detail="Token has expired")
        raise HTTPException(status_code=401, detail="Invalid token")

def get_current_admin(authorization: str = Header(None)):
    """Dependency to get current admin from JWT token"""
    if not authorization:
        raise HTTPException(status_code=401, detail="Authorization header missing")
    
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid authorization format")
    
    token = authorization.split(" ")[1]
    payload = verify_jwt_token(token)
    
    admin = admins_collection.find_one({"username": payload["sub"]})
    if not admin:
        raise HTTPException(status_code=401, detail="Admin not found")
    
    return {
        "username": admin["username"],
        "fullName": admin["fullName"],
        "role": admin["role"]
    }

# ========================
# API ENDPOINTS
# ========================

@app.get("/api/health")
def health_check():
    return {"status": "running", "timestamp": datetime.now().isoformat()}

# --- Admin Authentication ---
@app.post("/api/admin/login")
def admin_login(credentials: AdminLogin):
    """Admin login endpoint"""
    admin = admins_collection.find_one({"username": credentials.username})
    
    if not admin:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    if admin["password"] != hash_password(credentials.password):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    token = create_jwt_token(admin["username"], admin["role"])
    
    return {
        "token": token,
        "admin": {
            "username": admin["username"],
            "fullName": admin["fullName"],
            "role": admin["role"]
        },
        "message": "Login successful"
    }

@app.get("/api/admin/verify")
def verify_admin_token(current_admin: dict = Depends(get_current_admin)):
    """Verify if admin token is valid"""
    return {
        "valid": True,
        "admin": current_admin
    }

@app.post("/api/admin/create")
def create_admin(admin_data: AdminCreate, current_admin: dict = Depends(get_current_admin)):
    """Create new admin (only superadmin can do this)"""
    if current_admin["role"] != "superadmin":
        raise HTTPException(status_code=403, detail="Only superadmin can create new admins")
    
    # Check if username exists
    if admins_collection.find_one({"username": admin_data.username}):
        raise HTTPException(status_code=400, detail="Username already exists")
    
    new_admin = {
        "username": admin_data.username,
        "password": hash_password(admin_data.password),
        "fullName": admin_data.fullName,
        "role": admin_data.role,
        "createdAt": datetime.utcnow(),
        "createdBy": current_admin["username"]
    }
    
    admins_collection.insert_one(new_admin)
    
    return AdminResponse(
        username=admin_data.username,
        fullName=admin_data.fullName,
        role=admin_data.role,
        message="Admin created successfully"
    )

@app.get("/api/admin/list")
def list_admins(current_admin: dict = Depends(get_current_admin)):
    """List all admins (only superadmin)"""
    if current_admin["role"] != "superadmin":
        raise HTTPException(status_code=403, detail="Unauthorized")
    
    admins = list(admins_collection.find({}, {"_id": 0, "password": 0}))
    return {"admins": admins, "total": len(admins)}

@app.delete("/api/admin/delete/{username}")
def delete_admin(username: str, current_admin: dict = Depends(get_current_admin)):
    """Delete an admin (only superadmin, cannot delete self)"""
    if current_admin["role"] != "superadmin":
        raise HTTPException(status_code=403, detail="Unauthorized")
    
    if username == "admin":
        raise HTTPException(status_code=400, detail="Cannot delete the default admin")
    
    if username == current_admin["username"]:
        raise HTTPException(status_code=400, detail="Cannot delete yourself")
    
    result = admins_collection.delete_one({"username": username})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Admin not found")
    
    return {"message": f"Admin '{username}' deleted successfully"}

# --- Google OAuth ---
@app.get("/api/auth/login")
async def login_via_google(request: Request):
    # Use configured redirect URI when present; otherwise derive from current request.
    if GOOGLE_REDIRECT_URI:
        redirect_uri = GOOGLE_REDIRECT_URI
    else:
        base = str(request.base_url).rstrip('/')
        redirect_path = app.url_path_for('auth_callback')
        redirect_uri = f"{base}{redirect_path}"
    print(f"[OAuth] Redirect URI -> {redirect_uri}")
    return await oauth.google.authorize_redirect(request, redirect_uri)

@app.get("/api/auth/callback")
async def auth_callback(request: Request):
    try:
        token = await oauth.google.authorize_access_token(request)
        user_info = token.get('userinfo')
        if not user_info:
            user_info = await oauth.google.userinfo(token=token)

        email = user_info.get('email')
        name = user_info.get('name', '')
        google_id = user_info.get('sub')

        if not email:
            raise HTTPException(status_code=400, detail="Google account email not available")

        await users_async_collection.update_one(
            {"email": email},
            {
                "$set": {
                    "email": email,
                    "name": name,
                    "googleId": google_id,
                    "lastLoginAt": datetime.utcnow(),
                },
                "$setOnInsert": {"createdAt": datetime.utcnow()},
            },
            upsert=True,
        )

        existing = await registrations_async_collection.find_one({"email": email}, {"_id": 1})
        already_registered = existing is not None
            
        return HTMLResponse(f"""
            <script>
                window.opener.postMessage({{
                    "status": "success",
                    "email": "{_safe_js_text(email)}",
                    "name": "{_safe_js_text(name)}",
                    "google_id": "{_safe_js_text(google_id or '')}",
                    "alreadyRegistered": {"true" if already_registered else "false"}
                }}, "*");
                window.close();
            </script>
        """)
    except Exception as e:
        print(f"[OAuth] Callback error: {e}")
        return HTMLResponse(f"""
            <script>
                window.opener.postMessage({{
                    "status": "failed",
                    "error": "{_safe_js_text(str(e))}"
                }}, "*");
                window.close();
            </script>
        """)

# --- Participant ID Preview (final ID is generated post-payment only) ---
@app.get("/api/generate-id")
async def generate_participant_id():
    return {"participantId": "GENERATED_AFTER_PAYMENT"}

# --- Generate Multiple Participant IDs (for team members) ---
@app.get("/api/generate-member-ids/{count}")
async def generate_member_ids(count: int):
    if count < 1 or count > MAX_TEAM_MEMBERS:
        raise HTTPException(status_code=400, detail=f"Count must be between 1 and {MAX_TEAM_MEMBERS}")

    return {"participantIds": [f"GENERATED_AFTER_PAYMENT_{index:02d}" for index in range(2, count + 2)]}

# --- Team ID Generation ---
@app.get("/api/generate-team-id")
async def generate_team_id():
    return {"teamId": "GENERATED_AFTER_PAYMENT"}


@app.get("/api/team/{team_id}/leader-details", response_model=LeaderDetailsResponse)
async def team_leader_details(team_id: str):
    team = await teams_async_collection.find_one({"teamId": team_id}, {"_id": 0})
    if not team:
        raise HTTPException(status_code=404, detail="Team not found")

    return LeaderDetailsResponse(
        teamId=team["teamId"],
        leaderId=team["leaderId"],
        collegeName=team["collegeName"],
        branch=team["branch"],
        projectSelected=team["projectSelected"],
    )

# --- College Endpoints ---
@app.get("/api/colleges")
async def get_colleges():
    """Get all colleges for dropdown"""
    colleges = await colleges_async_collection.find({}, {"_id": 0}).sort("name", 1).to_list(length=1000)
    return {"colleges": colleges, "total": len(colleges)}

@app.post("/api/colleges", status_code=status.HTTP_201_CREATED)
def add_college(college: CollegeCreate, current_admin: dict = Depends(get_current_admin)):
    """Add a new college (admin only)"""
    try:
        colleges_collection.insert_one({
            "name": college.name,
            "city": college.city or "",
            "state": college.state or "",
            "addedBy": current_admin["username"],
            "addedAt": datetime.utcnow()
        })
        return {"message": "College added successfully", "name": college.name}
    except DuplicateKeyError:
        raise HTTPException(status_code=400, detail="College already exists")

@app.delete("/api/colleges/{college_name}")
def delete_college(college_name: str, current_admin: dict = Depends(get_current_admin)):
    """Delete a college (admin only)"""
    if current_admin["role"] != "superadmin":
        raise HTTPException(status_code=403, detail="Only superadmin can delete colleges")
    
    result = colleges_collection.delete_one({"name": college_name})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="College not found")
    
    return {"message": f"College '{college_name}' deleted successfully"}

# --- Duplicate Check Endpoints ---
@app.get("/api/check-email/{email}")
async def check_email_exists(email: str):
    existing = await registrations_async_collection.find_one({"email": email}, {"_id": 1})
    return {"exists": existing is not None}

@app.get("/api/check-roll-number/{roll_number}")
async def check_roll_number_exists(roll_number: str):
    existing = await registrations_async_collection.find_one({"rollNumber": roll_number}, {"_id": 1})
    if existing:
        return {"exists": True, "message": "Already exists."}
    return {"exists": False}

@app.get("/api/check-github/{github_profile:path}")
async def check_github_exists(github_profile: str):
    existing = await registrations_async_collection.find_one({"githubProfile": github_profile}, {"_id": 1})
    if existing:
        return {"exists": True, "message": "Already exists."}
    return {"exists": False}

@app.post("/api/check-duplicate")
async def check_duplicate(data: DuplicateCheck):
    """Check for duplicate registration based on email, roll number, or GitHub profile"""
    checks = []
    
    if data.email:
        if await registrations_async_collection.find_one({"email": data.email}, {"_id": 1}):
            checks.append({"field": "email", "exists": True, "message": "This email is already registered."})
    
    if data.rollNumber:
        if await registrations_async_collection.find_one({"rollNumber": data.rollNumber}, {"_id": 1}):
            checks.append({"field": "rollNumber", "exists": True, "message": "Already exists."})
    
    if data.githubProfile:
        if await registrations_async_collection.find_one({"githubProfile": data.githubProfile}, {"_id": 1}):
            checks.append({"field": "githubProfile", "exists": True, "message": "Already exists."})
    
    has_duplicate = len(checks) > 0
    return {"hasDuplicate": has_duplicate, "duplicates": checks}

# --- Payment Endpoints ---
@app.post("/api/payment/order", response_model=PaymentOrderResponse)
async def create_payment_order(request: PaymentOrderRequest):
    # Calculate amount
    base_amount = 20
    if request.participationMode == "team":
        # Leader + team members
        total_members = 1 + request.teamMembersCount
        amount = base_amount * total_members
    else:
        amount = base_amount

    cf_order_id = f"CF_{int(datetime.utcnow().timestamp())}_{secrets.token_hex(4)}"
    customer_id = f"cust_{abs(hash(request.email)) % 10_000_000}"

    try:
        order = await cashfree_client.create_order(
            order_id=cf_order_id,
            order_amount=float(amount),
            customer_id=customer_id,
            customer_name=request.fullName,
            customer_email=str(request.email),
            customer_phone=request.mobile,
        )

        await payments_async_collection.update_one(
            {"cf_order_id": cf_order_id},
            {
                "$set": {
                    "cf_order_id": cf_order_id,
                    "payment_gateway": "cashfree",
                    "status": "created",
                    "payment_status": "created",
                    "order_amount": float(amount),
                    "currency": "INR",
                    "email": str(request.email),
                    "fullName": request.fullName,
                    "participationMode": request.participationMode,
                    "mobile": request.mobile,
                    "updatedAt": datetime.utcnow(),
                },
                "$setOnInsert": {"createdAt": datetime.utcnow()},
            },
            upsert=True,
        )

        return PaymentOrderResponse(
            orderId=order["order_id"],
            amount=float(amount),
            currency="INR",
            paymentSessionId=order["payment_session_id"],
            paymentGateway="cashfree",
            environment=CASHFREE_ENVIRONMENT,
        )
    except CashfreeAPIError as e:
        logger.error("Cashfree order creation failed: %s", e)
        error_text = str(e).lower()
        if CASHFREE_ALLOW_MOCK_ON_BLOCK and e.status_code == 403 and "ip" in error_text and "allow" in error_text:
            mock_order_id = f"MOCK_CF_{int(datetime.utcnow().timestamp())}_{secrets.token_hex(3)}"
            mock_payment_id = f"MOCK_PAY_{secrets.token_hex(6)}"

            await payments_async_collection.update_one(
                {"cf_order_id": mock_order_id},
                {
                    "$set": {
                        "cf_order_id": mock_order_id,
                        "cf_payment_id": mock_payment_id,
                        "payment_gateway": "cashfree",
                        "mock_mode": True,
                        "status": "created",
                        "payment_status": "created",
                        "order_amount": float(amount),
                        "currency": "INR",
                        "email": str(request.email),
                        "fullName": request.fullName,
                        "participationMode": request.participationMode,
                        "mobile": request.mobile,
                        "updatedAt": datetime.utcnow(),
                    },
                    "$setOnInsert": {"createdAt": datetime.utcnow()},
                },
                upsert=True,
            )

            return PaymentOrderResponse(
                orderId=mock_order_id,
                amount=float(amount),
                currency="INR",
                paymentSessionId="MOCK_SESSION",
                paymentGateway="cashfree",
                environment=CASHFREE_ENVIRONMENT,
                mockMode=True,
                mockPaymentId=mock_payment_id,
                message="Cashfree IP allowlist blocked this request. Mock payment mode enabled for local testing.",
            )

        raise HTTPException(status_code=e.status_code, detail=str(e))
    except Exception as e:
        logger.exception("Error creating Cashfree order")
        raise HTTPException(status_code=500, detail=f"Payment Gateway Error: {str(e)}")

# --- Payment Verification Endpoint ---
@app.post("/api/payment/verify")
async def verify_payment(data: PaymentVerification):
    try:
        verified_payment = await verify_cashfree_payment(data.cf_order_id, data.cf_payment_id)
        cf_payment_id = (
            verified_payment.get("cf_payment_id")
            or verified_payment.get("payment_id")
            or verified_payment.get("paymentId")
        )
        payment_status = str(verified_payment.get("payment_status", "SUCCESS")).lower()

        await payments_async_collection.update_one(
            {"cf_order_id": data.cf_order_id},
            {
                "$set": {
                    "cf_order_id": data.cf_order_id,
                    "cf_payment_id": cf_payment_id,
                    "payment_gateway": "cashfree",
                    "status": "verified",
                    "payment_status": payment_status,
                    "verifiedAt": datetime.utcnow(),
                    "updatedAt": datetime.utcnow(),
                },
                "$setOnInsert": {"createdAt": datetime.utcnow()},
            },
            upsert=True,
        )

        return {
            "status": "success",
            "message": "Payment verified successfully",
            "cf_order_id": data.cf_order_id,
            "cf_payment_id": cf_payment_id,
        }
    except HTTPException:
        raise
    except CashfreeAPIError as e:
        logger.error("Cashfree payment verification failed: %s", e)
        raise HTTPException(status_code=e.status_code, detail=str(e))
    except Exception as e:
        logger.exception("Payment verification error")
        raise HTTPException(status_code=500, detail=f"Payment verification error: {str(e)}")


@app.post("/api/payment/success-callback")
async def payment_success_callback(data: PaymentSuccessCallback):
    try:
        verified_payment = await verify_cashfree_payment(data.cf_order_id, data.cf_payment_id)
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Payment success callback verification failed")
        raise HTTPException(status_code=500, detail=f"Callback verification failed: {exc}")

    cf_payment_id = (
        verified_payment.get("cf_payment_id")
        or verified_payment.get("payment_id")
        or verified_payment.get("paymentId")
    )

    registration = await registrations_async_collection.find_one({"participantId": data.participantId})
    if not registration:
        raise HTTPException(status_code=404, detail="Registration not found")

    await registrations_async_collection.update_one(
        {"participantId": data.participantId},
        {
            "$set": {
                "paymentStatus": "paid",
                "payment_status": "paid",
                "payment_gateway": "cashfree",
                "cf_order_id": data.cf_order_id,
                "cf_payment_id": cf_payment_id,
                "updatedAt": datetime.utcnow(),
            }
        },
    )

    await payments_async_collection.update_one(
        {"cf_order_id": data.cf_order_id},
        {
            "$set": {
                "participantId": data.participantId,
                "payment_gateway": "cashfree",
                "cf_order_id": data.cf_order_id,
                "cf_payment_id": cf_payment_id,
                "status": "paid",
                "payment_status": "paid",
                "updatedAt": datetime.utcnow(),
            },
            "$setOnInsert": {"createdAt": datetime.utcnow()},
        },
        upsert=True,
    )

    return {"status": "success", "message": "Payment callback handled"}


@app.post("/api/payment/webhook")
async def cashfree_webhook(
    request: Request,
    x_webhook_signature: str | None = Header(default=None, alias="x-webhook-signature"),
):
    raw_body = await request.body()

    if not x_webhook_signature or not cashfree_client.verify_webhook_signature(raw_body, x_webhook_signature):
        raise HTTPException(status_code=400, detail="Invalid webhook signature")

    payload = await request.json()
    data = payload.get("data", {})
    order_data = data.get("order", {})
    payment_data = data.get("payment", {})

    cf_order_id = order_data.get("order_id") or payment_data.get("order_id")
    cf_payment_id = payment_data.get("cf_payment_id") or payment_data.get("payment_id")
    payment_status = str(payment_data.get("payment_status") or payload.get("type") or "").lower()

    if not cf_order_id:
        return {"status": "ignored", "message": "Webhook does not contain order ID"}

    await payments_async_collection.update_one(
        {"cf_order_id": cf_order_id},
        {
            "$set": {
                "payment_gateway": "cashfree",
                "cf_order_id": cf_order_id,
                "cf_payment_id": cf_payment_id,
                "status": payment_status or "updated",
                "payment_status": payment_status or "updated",
                "webhookPayload": payload,
                "updatedAt": datetime.utcnow(),
            },
            "$setOnInsert": {"createdAt": datetime.utcnow()},
        },
        upsert=True,
    )

    return {"status": "success"}

# --- Student Registration ---
@app.post("/api/register", response_model=StudentResponse, status_code=status.HTTP_201_CREATED)
async def register_student(student: StudentRegister):
    # Verify Payment First
    if not student.cf_order_id:
         raise HTTPException(status_code=400, detail="Payment details are missing. Please complete the payment first.")

    try:
        verified_payment = await verify_cashfree_payment(student.cf_order_id, student.cf_payment_id)
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Payment verification failed during registration")
        raise HTTPException(status_code=500, detail=f"Payment verification error: {str(e)}")

    cf_payment_id = (
        verified_payment.get("cf_payment_id")
        or verified_payment.get("payment_id")
        or verified_payment.get("paymentId")
    )

    await payments_async_collection.update_one(
        {"cf_order_id": student.cf_order_id},
        {
            "$set": {
                "cf_order_id": student.cf_order_id,
                "cf_payment_id": cf_payment_id,
                "payment_gateway": "cashfree",
                "status": "success",
                "payment_status": "success",
                "updatedAt": datetime.utcnow(),
            },
            "$setOnInsert": {"createdAt": datetime.utcnow()},
        },
        upsert=True,
    )

    # Validate uniqueness for leader/individual.
    duplicate_queries = [
        {"email": student.email},
        {"mobile": student.mobile},
        {"rollNumber": student.rollNumber},
        {"githubProfile": student.githubProfile},
    ]
    for query in duplicate_queries:
        exists = await registrations_async_collection.find_one(query, {"_id": 1})
        if exists:
            raise HTTPException(status_code=400, detail="Duplicate registration data detected.")

    registration_time = datetime.utcnow()
    team_member_ids: List[str] = []

    if student.participationMode == "individual":
        # ID generation happens only after payment has been verified as successful.
        for _ in range(10):
            participant_id = await generate_unique_individual_id()
            doc = student.model_dump()
            doc["participantId"] = participant_id
            doc["teamId"] = None
            doc["registrationDate"] = registration_time
            doc["paymentStatus"] = "success"
            doc["payment_status"] = "success"
            doc["createdAt"] = registration_time
            doc["updatedAt"] = registration_time
            try:
                await registrations_async_collection.insert_one(doc)
                break
            except DuplicateKeyError:
                continue
        else:
            raise HTTPException(status_code=409, detail="Failed to allocate unique participant ID")

        await users_async_collection.update_one(
            {"email": student.email},
            {"$set": {"name": student.fullName, "googleId": None, "updatedAt": registration_time}, "$setOnInsert": {"createdAt": registration_time}},
            upsert=True,
        )

        await payments_async_collection.update_one(
            {"cf_order_id": student.cf_order_id},
            {
                "$set": {
                    "participantId": participant_id,
                    "mode": "individual",
                    "amount": student.payment_amount,
                    "order_amount": student.payment_amount,
                    "currency": student.payment_currency,
                    "status": "success",
                    "payment_status": "success",
                    "payment_gateway": "cashfree",
                    "cf_order_id": student.cf_order_id,
                    "cf_payment_id": cf_payment_id,
                    "updatedAt": registration_time,
                },
                "$setOnInsert": {"createdAt": registration_time},
            },
            upsert=True,
        )

        try:
            send_confirmation_email([student.email], [participant_id], student.fullName, "individual")
        except Exception as email_err:
            print(f"[Email] Failed to send individual confirmation: {email_err}")

        return StudentResponse(
            participantId=participant_id,
            fullName=student.fullName,
            email=str(student.email),
            message="Registration successful! Thank you for registering.",
        )

    # Team mode
    if not student.teamMembers or len(student.teamMembers) < 1 or len(student.teamMembers) > MAX_TEAM_MEMBERS:
        raise HTTPException(status_code=400, detail=f"Team mode requires 1 to {MAX_TEAM_MEMBERS} team members plus 1 leader")

    for _ in range(10):
        team_id = await generate_unique_team_base_id()
        leader_id = f"{team_id}_01"

        existing_leader_id = await registrations_async_collection.find_one({"participantId": leader_id}, {"_id": 1})
        if existing_leader_id:
            continue
        break
    else:
        raise HTTPException(status_code=409, detail="Failed to allocate unique team IDs")

    leader_doc = student.model_dump()
    leader_doc["participantId"] = leader_id
    leader_doc["teamId"] = team_id
    leader_doc["isTeamLeader"] = True
    leader_doc["registrationDate"] = registration_time
    leader_doc["paymentStatus"] = "success"
    leader_doc["payment_status"] = "success"
    leader_doc["createdAt"] = registration_time
    leader_doc["updatedAt"] = registration_time

    member_docs = []
    member_roster = [
        {
            "name": student.fullName,
            "email": str(student.email),
            "mobile": student.mobile,
            "role": "leader",
            "participant_id": leader_id,
        }
    ]

    for index, member in enumerate(student.teamMembers, start=2):
        existing_member = await registrations_async_collection.find_one(
            {"$or": [{"email": str(member.email)}, {"mobile": member.mobile}, {"rollNumber": member.rollNumber}]},
            {"_id": 1},
        )
        if existing_member:
            raise HTTPException(status_code=400, detail=f"Duplicate data for team member {member.fullName}")

        member_id = f"{team_id}_{index:02d}"
        existing_id = await registrations_async_collection.find_one({"participantId": member_id}, {"_id": 1})
        if existing_id:
            raise HTTPException(status_code=409, detail="Team member ID conflict. Please retry payment callback.")
        team_member_ids.append(member_id)

        member_doc = {
            "participantId": member_id,
            "fullName": member.fullName,
            "email": str(member.email),
            "mobile": member.mobile,
            "branch": student.branch,  # Backend-enforced inheritance from leader
            "collegeName": student.collegeName,  # Backend-enforced inheritance from leader
            "city": student.city,
            "rollNumber": member.rollNumber,
            "githubProfile": member.githubProfile,
            "projectSelected": student.projectSelected,  # Backend-enforced inheritance from leader
            "participationMode": "team",
            "teamId": team_id,
            "teamName": student.teamName,
            "isTeamLeader": False,
            "registrationDate": registration_time,
            "createdAt": registration_time,
            "updatedAt": registration_time,
            "paymentStatus": "success",
            "payment_status": "success",
        }
        member_docs.append(member_doc)
        member_roster.append(
            {
                "name": member.fullName,
                "email": str(member.email),
                "mobile": member.mobile,
                "role": "member",
                "participant_id": member_id,
            }
        )

    # Ensure team collection uses required structure.
    team_doc = {
        "teamId": team_id,
        "leaderId": leader_id,
        "payment_status": "success",
        "teamName": student.teamName,
        "collegeName": student.collegeName,
        "branch": student.branch,
        "projectSelected": student.projectSelected,
        "members": member_roster,
        "createdAt": registration_time,
        "updatedAt": registration_time,
    }

    try:
        await teams_async_collection.insert_one(team_doc)
        await registrations_async_collection.insert_one(leader_doc)
        await registrations_async_collection.insert_many(member_docs)
    except DuplicateKeyError:
        raise HTTPException(status_code=409, detail="Duplicate team/participant ID conflict. Retry registration.")

    await payments_async_collection.update_one(
        {"cf_order_id": student.cf_order_id},
        {
            "$set": {
                "participantId": leader_id,
                "teamId": team_id,
                "mode": "team",
                "amount": student.payment_amount,
                "order_amount": student.payment_amount,
                "currency": student.payment_currency,
                "status": "success",
                "payment_status": "success",
                "payment_gateway": "cashfree",
                "cf_order_id": student.cf_order_id,
                "cf_payment_id": cf_payment_id,
                "updatedAt": registration_time,
            },
            "$setOnInsert": {"createdAt": registration_time},
        },
        upsert=True,
    )

    await users_async_collection.update_one(
        {"email": student.email},
        {"$set": {"name": student.fullName, "googleId": None, "updatedAt": registration_time}, "$setOnInsert": {"createdAt": registration_time}},
        upsert=True,
    )

    recipients = [str(student.email)] + [str(m.email) for m in student.teamMembers]
    all_ids = [leader_id] + team_member_ids
    try:
        send_confirmation_email(recipients, all_ids, student.fullName, "team")
    except Exception as email_err:
        print(f"[Email] Failed to send team confirmation: {email_err}")

    return StudentResponse(
        participantId=leader_id,
        fullName=student.fullName,
        email=str(student.email),
        message="Registration successful! Thank you for registering.",
        teamMemberIds=team_member_ids,
    )

# --- Check Result by Email ---
@app.post("/api/check-result")
async def check_result(data: ResultCheck):
    student = await registrations_async_collection.find_one({"email": data.email})
    if not student:
        raise HTTPException(status_code=404, detail="No registration found with this email.")
    
    payment_status = (student.get("paymentStatus") or student.get("payment_status") or "").lower()
    status = "Verified" if payment_status == "success" else "Not Verified"

    return {
        "participantId": student.get("participantId"),
        "fullName": student.get("fullName"),
        "email": student.get("email"),
        "projectSelected": student.get("projectSelected"),
        "participationMode": student.get("participationMode"),
        "teamName": student.get("teamName"),
        "isSelected": student.get("isSelected"),
        "status": status
    }

# ========================
# ADMIN ENDPOINTS (Protected)
# ========================

@app.get("/api/admin/students")
def get_all_students(skip: int = 0, limit: int = 100, current_admin: dict = Depends(get_current_admin)):
    students = list(students_collection.find({}, {"_id": 0}).skip(skip).limit(limit))
    total = students_collection.count_documents({})
    return {"students": students, "total": total}

@app.get("/api/admin/teams")
def get_all_teams(current_admin: dict = Depends(get_current_admin)):
    teams = list(teams_collection.find({}, {"_id": 0}))
    return {"teams": teams, "total": len(teams)}

@app.put("/api/admin/validate")
def validate_student(validation: AdminValidation, current_admin: dict = Depends(get_current_admin)):
    result = students_collection.update_one(
        {"participantId": validation.participantId},
        {"$set": {
            "isSelected": validation.isSelected,
            "reviewedBy": validation.reviewedBy,
            "reviewedAt": datetime.utcnow()
        }}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Student not found.")
    
    # Log validation action
    admin_validation_collection.insert_one({
        "participantId": validation.participantId,
        "isSelected": validation.isSelected,
        "reviewedBy": validation.reviewedBy,
        "adminUser": current_admin["username"],
        "timestamp": datetime.utcnow()
    })
    
    return {"message": "Validation updated successfully."}

@app.get("/api/admin/export-excel")
def export_to_excel(current_admin: dict = Depends(get_current_admin)):
    try:
        import pandas as pd
        
        students = list(students_collection.find({}, {"_id": 0}))
        if not students:
            raise HTTPException(status_code=404, detail="No data to export.")
        
        df = pd.DataFrame(students)
        
        # Rename columns for clarity if they exist
        rename_map = {
            'participantId': 'Participant ID',
            'fullName': 'Full Name',
            'email': 'Email',
            'mobile': 'Mobile',
            'branch': 'Branch',
            'collegeName': 'College',
            'city': 'City',
            'rollNumber': 'Roll Number',
            'githubProfile': 'GitHub Profile',
            'projectSelected': 'Project',
            'participationMode': 'Mode',
            'registrationDate': 'Registration Date',
            'payment_gateway': 'Payment Gateway',
            'cf_payment_id': 'Cashfree Payment ID',
            'cf_order_id': 'Cashfree Order ID',
            'payment_status': 'Payment Status',
            'order_amount': 'Order Amount (INR)',
            'payment_amount': 'Amount (INR)',
            'payment_currency': 'Currency',
            'isSelected': 'Selected',
            'reviewedBy': 'Reviewed By'
        }
        df.rename(columns=rename_map, inplace=True)

        # Convert datetime columns
        for col in df.columns:
            if df[col].dtype == 'object':
                try:
                    df[col] = pd.to_datetime(df[col])
                except:
                    pass
        
        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            df.to_excel(writer, index=False, sheet_name='Registrations')
        output.seek(0)
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": "attachment; filename=hackathon_registrations.xlsx"}
        )
    except ImportError:
        raise HTTPException(status_code=500, detail="pandas or openpyxl not installed. Run: pip install pandas openpyxl")

@app.get("/api/admin/stats")
def get_stats(current_admin: dict = Depends(get_current_admin)):
    total_registrations = students_collection.count_documents({})
    individual_count = students_collection.count_documents({"participationMode": "individual"})
    team_leader_count = students_collection.count_documents({"participationMode": "team"})
    total_teams = teams_collection.count_documents({})
    selected_count = students_collection.count_documents({"isSelected": True})
    pending_count = students_collection.count_documents({"isSelected": None})
    
    # Calculate total team members from teams collection
    team_members_count = 0
    teams = teams_collection.find({})
    for team in teams:
        team_members_count += len(team.get("members", []))
    
    # Total users = individual participants + team leaders + all team members
    total_users = individual_count + team_leader_count + team_members_count
    
    # Project distribution
    pipeline = [{"$group": {"_id": "$projectSelected", "count": {"$sum": 1}}}]
    project_stats = list(students_collection.aggregate(pipeline))
    
    return {
        "totalRegistrations": total_registrations,
        "individualParticipants": individual_count,
        "teamLeaders": team_leader_count,
        "teamMembersCount": team_members_count,
        "totalTeams": total_teams,
        "totalUsers": total_users,  # New field: total registered users including team members
        "selectedCount": selected_count,
        "pendingReview": pending_count,
        "projectDistribution": project_stats
    }

@app.get("/api/admin/teams-detailed")
def get_teams_detailed(current_admin: dict = Depends(get_current_admin)):
    """Get detailed team information with expandable member data"""
    teams = list(teams_collection.find({}, {"_id": 0}))
    
    detailed_teams = []
    for team in teams:
        # Get leader details from students collection
        leader = students_collection.find_one({"participantId": team.get("leaderId")}, {"_id": 0})
        
        detailed_team = {
            "teamId": team.get("teamId"),
            "teamName": team.get("teamName"),
            "collegeName": team.get("collegeName"),
            "branch": team.get("branch"),
            "city": team.get("city"),
            "projectSelected": team.get("projectSelected"),
            "totalMembers": team.get("totalMembers", len(team.get("members", [])) + 1),
            "createdAt": team.get("createdAt"),
            "leader": {
                "participantId": team.get("leaderId"),
                "fullName": leader.get("fullName") if leader else team.get("leaderName", ""),
                "email": team.get("leaderEmail"),
                "mobile": leader.get("mobile") if leader else "",
                "rollNumber": leader.get("rollNumber") if leader else "",
                "githubProfile": leader.get("githubProfile") if leader else "",
                "isSelected": leader.get("isSelected") if leader else None
            },
            "members": team.get("members", [])
        }
        detailed_teams.append(detailed_team)
    
    return {"teams": detailed_teams, "total": len(detailed_teams)}

# Serve Frontend (must be last)
app.mount("/", StaticFiles(directory=".", html=True), name="static")

if __name__ == "__main__":
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
