import hashlib
import os
from datetime import datetime

from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import MongoClient

load_dotenv()

MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("DB_NAME", "hackathon_db")

# Sync client kept for legacy/admin compatibility.
sync_client = MongoClient(MONGO_URI)
sync_db = sync_client[DB_NAME]

# Async client for primary registration flow.
async_client = AsyncIOMotorClient(MONGO_URI)
async_db = async_client[DB_NAME]

# Required collections
users_collection = sync_db["users"]
students_collection = sync_db["registrations"]  # Backward-compatible alias
registrations_collection = sync_db["registrations"]
teams_collection = sync_db["teams"]
payments_collection = sync_db["payments"]
admin_validation_collection = sync_db["admin_validation"]
admins_collection = sync_db["admins"]
colleges_collection = sync_db["colleges"]

# Async handles
users_async_collection = async_db["users"]
registrations_async_collection = async_db["registrations"]
teams_async_collection = async_db["teams"]
payments_async_collection = async_db["payments"]
colleges_async_collection = async_db["colleges"]
admins_async_collection = async_db["admins"]


def hash_password(password: str) -> str:
    """Hash password using SHA-256."""
    return hashlib.sha256(password.encode()).hexdigest()


def create_default_colleges() -> None:
    """Create default colleges if collection is empty."""
    if colleges_collection.count_documents({}) != 0:
        return

    default_colleges = [
        {"name": "Indian Institute of Technology (IIT) Delhi", "city": "Delhi", "state": "Delhi"},
        {"name": "Indian Institute of Technology (IIT) Bombay", "city": "Mumbai", "state": "Maharashtra"},
        {"name": "Indian Institute of Technology (IIT) Madras", "city": "Chennai", "state": "Tamil Nadu"},
        {"name": "Indian Institute of Technology (IIT) Kanpur", "city": "Kanpur", "state": "Uttar Pradesh"},
        {"name": "Indian Institute of Technology (IIT) Kharagpur", "city": "Kharagpur", "state": "West Bengal"},
        {"name": "National Institute of Technology (NIT) Trichy", "city": "Tiruchirappalli", "state": "Tamil Nadu"},
        {"name": "National Institute of Technology (NIT) Warangal", "city": "Warangal", "state": "Telangana"},
        {"name": "BITS Pilani", "city": "Pilani", "state": "Rajasthan"},
        {"name": "VIT University", "city": "Vellore", "state": "Tamil Nadu"},
        {"name": "SRM Institute of Science and Technology", "city": "Chennai", "state": "Tamil Nadu"},
        {"name": "Delhi Technological University", "city": "Delhi", "state": "Delhi"},
        {"name": "Anna University", "city": "Chennai", "state": "Tamil Nadu"},
        {"name": "Jawaharlal Nehru Technological University", "city": "Hyderabad", "state": "Telangana"},
        {"name": "Visvesvaraya Technological University", "city": "Belgaum", "state": "Karnataka"},
        {"name": "Punjab Technical University", "city": "Jalandhar", "state": "Punjab"},
        {"name": "Other", "city": "", "state": ""},
    ]
    colleges_collection.insert_many(default_colleges)


def create_default_admin() -> None:
    """Create default admin account if it doesn't exist."""
    existing = admins_collection.find_one({"username": "admin"})
    if existing:
        return

    admins_collection.insert_one(
        {
            "username": "admin",
            "password": hash_password("Spheronix@2026"),
            "fullName": "System Administrator",
            "role": "superadmin",
            "createdAt": datetime.utcnow(),
        }
    )


def initialize_sync_collections() -> None:
    """Initialize sync indexes and seed data."""
    users_collection.create_index("email", unique=True)
    registrations_collection.create_index("email", unique=True)
    registrations_collection.create_index("mobile", unique=True)
    registrations_collection.create_index("rollNumber", unique=True, sparse=True)
    registrations_collection.create_index("participantId", unique=True)
    teams_collection.create_index("teamId", unique=True)
    teams_collection.create_index("leaderId", unique=True)
    payments_collection.create_index("cf_order_id", unique=True, sparse=True)
    payments_collection.create_index("cf_payment_id", unique=True, sparse=True)
    payments_collection.create_index("razorpay_order_id", unique=True, sparse=True)
    payments_collection.create_index("razorpay_payment_id", unique=True, sparse=True)
    admins_collection.create_index("username", unique=True)
    colleges_collection.create_index("name", unique=True)

    create_default_colleges()
    create_default_admin()


async def initialize_async_collections() -> None:
    """Initialize async indexes for primary flow collections."""
    await users_async_collection.create_index("email", unique=True)
    await registrations_async_collection.create_index("email", unique=True)
    await registrations_async_collection.create_index("mobile", unique=True)
    await registrations_async_collection.create_index("rollNumber", unique=True, sparse=True)
    await registrations_async_collection.create_index("participantId", unique=True)
    await teams_async_collection.create_index("teamId", unique=True)
    await teams_async_collection.create_index("leaderId", unique=True)
    await payments_async_collection.create_index("cf_order_id", unique=True, sparse=True)
    await payments_async_collection.create_index("cf_payment_id", unique=True, sparse=True)
    await payments_async_collection.create_index("razorpay_order_id", unique=True, sparse=True)
    await payments_async_collection.create_index("razorpay_payment_id", unique=True, sparse=True)


initialize_sync_collections()


def get_database():
    return sync_db


def get_async_database():
    return async_db
