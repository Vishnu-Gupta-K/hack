/**
 * Spheronix Hackathon Registration System
 * Main JavaScript File
 */

document.addEventListener('DOMContentLoaded', () => {
    // ============ Constants ============
    const MAX_TEAM_MEMBERS = 4; // Max 4 additional members + 1 leader = 5 total
    
    // ============ Elements ============
    const landingView = document.getElementById('landing-view');
    const registerView = document.getElementById('register-view');
    const resultsView = document.getElementById('results-view');
    const instructionsView = document.getElementById('instructions-view');
    
    const btnStartRegister = document.getElementById('btn-start-register');
    const btnCheckResults = document.getElementById('btn-check-results');
    const btnInstructions = document.getElementById('btn-instructions');
    const btnBackLanding = document.getElementById('btn-back-landing');
    const btnBackResults = document.getElementById('btn-back-results');
    const btnBackInstructions = document.getElementById('btn-back-instructions');
    const btnStartFromInstructions = document.getElementById('btn-start-from-instructions');
    
    const navHome = document.getElementById('nav-home');
    const navResults = document.getElementById('nav-results');
    
    const step1 = document.getElementById('step-1');
    const step2 = document.getElementById('step-2');
    const step3 = document.getElementById('step-3');
    const successView = document.getElementById('success-view');
    
    const stepIndicator1 = document.getElementById('step-indicator-1');
    const stepIndicator2 = document.getElementById('step-indicator-2');
    const stepIndicator3 = document.getElementById('step-indicator-3');
    const progressLine1 = document.getElementById('progress-line-1');
    const progressLine2 = document.getElementById('progress-line-2');
    
    const btnGoogleAuth = document.getElementById('btn-google-auth');
    const authError = document.getElementById('auth-error');
    const alreadyRegistered = document.getElementById('already-registered');
    
    const registrationForm = document.getElementById('registration-form');
    const resultsForm = document.getElementById('results-form');
    
    // Form Fields
    const participantIdInput = document.getElementById('participantId');
    const registrationDateInput = document.getElementById('registrationDate');
    const fullNameInput = document.getElementById('fullName');
    const emailInput = document.getElementById('email');
    const mobileInput = document.getElementById('mobile');
    const branchInput = document.getElementById('branch');
    const collegeNameInput = document.getElementById('collegeName');
    const cityInput = document.getElementById('city');
    const rollNumberInput = document.getElementById('rollNumber');
    const githubProfileInput = document.getElementById('githubProfile');
    const projectSelectedInput = document.getElementById('projectSelected');
    const participationModeInputs = document.querySelectorAll('input[name="participationMode"]');
    
    // Team Fields
    const teamIdInput = document.getElementById('teamId');
    const teamNameInput = document.getElementById('teamName');
    const leaderInfoEl = document.getElementById('leader-info');
    const leaderCollegeInfoEl = document.getElementById('leader-college-info');
    const btnAddMember = document.getElementById('btn-add-member');
    const memberLimitMsg = document.getElementById('member-limit-msg');
    const btnBackStep2 = document.getElementById('btn-back-step2');
    const btnNextPayment = document.getElementById('btn-next-payment');
    
    // Payment Fields
    const step4 = document.getElementById('step-4');
    const btnPayNow = document.getElementById('btn-pay-now');
    const btnSubmitFinal = document.getElementById('btn-submit-final');
    const btnBackStep3 = document.getElementById('btn-back-step3');
    
    // ============ State ============
    let currentUser = {
        email: '',
        name: '',
        googleId: '',
        participantId: ''
    };
    
    let currentPayment = {
        orderId: '',
        paymentId: '',
        gateway: 'cashfree',
        amount: 0
    };
    
    let teamMemberCount = 1;
    let navigationHistory = [];
    let currentStep = 1;
    let collegesLoaded = false;
    
    // ============ View Navigation ============
    function showView(view, addToHistory = true) {
        const allViews = [landingView, registerView, resultsView, instructionsView];
        
        // Save current view to history before changing
        if (addToHistory) {
            const currentView = allViews.find(v => v.classList.contains('active'));
            if (currentView && currentView !== view) {
                navigationHistory.push(currentView);
            }
        }
        
        allViews.forEach(v => {
            v.classList.remove('active');
            v.classList.add('hidden');
        });
        view.classList.remove('hidden');
        view.classList.add('active');
        
        // Update nav
        document.querySelectorAll('.nav-links a').forEach(a => a.classList.remove('active'));
        if (view === landingView) navHome.classList.add('active');
        if (view === resultsView) navResults.classList.add('active');
    }
    
    function goBack() {
        if (navigationHistory.length > 0) {
            const previousView = navigationHistory.pop();
            showView(previousView, false);
        } else {
            showView(landingView, false);
        }
    }
    
    function showStep(stepNum) {
        [step1, step2, step3, step4, successView].forEach(s => {
            s.classList.remove('active-step');
            s.classList.add('hidden-step');
        });
        
        // Reset indicators
        [stepIndicator1, stepIndicator2, stepIndicator3].forEach(s => {
            s.classList.remove('active', 'completed');
        });
        progressLine1.classList.remove('active');
        progressLine2.classList.remove('active');
        
        // Step 4 indicator (reusing step 3 indicator logic or adding new one if needed, but for now I will just mark all 3 as completed)
        const stepIndicator4 = document.getElementById('step-indicator-4');
        const progressLine3 = document.getElementById('progress-line-3');
        if (stepIndicator4) stepIndicator4.classList.remove('active', 'completed');
        if (progressLine3) progressLine3.classList.remove('active');

        if (stepNum === 1) {
            step1.classList.remove('hidden-step');
            step1.classList.add('active-step');
            stepIndicator1.classList.add('active');
        } else if (stepNum === 2) {
            step2.classList.remove('hidden-step');
            step2.classList.add('active-step');
            stepIndicator1.classList.add('completed');
            stepIndicator2.classList.add('active');
            progressLine1.classList.add('active');
        } else if (stepNum === 3) {
            step3.classList.remove('hidden-step');
            step3.classList.add('active-step');
            stepIndicator1.classList.add('completed');
            stepIndicator2.classList.add('completed');
            stepIndicator3.classList.add('active');
            progressLine1.classList.add('active');
            progressLine2.classList.add('active');
        } else if (stepNum === 4) {
            step4.classList.remove('hidden-step');
            step4.classList.add('active-step');
            stepIndicator1.classList.add('completed');
            stepIndicator2.classList.add('completed');
            stepIndicator3.classList.add('completed');
            if (stepIndicator4) stepIndicator4.classList.add('active');
            progressLine1.classList.add('active');
            progressLine2.classList.add('active');
            if (progressLine3) progressLine3.classList.add('active');
        } else if (stepNum === 'success') {
            successView.classList.remove('hidden-step');
            successView.classList.add('active-step');
            [stepIndicator1, stepIndicator2, stepIndicator3].forEach(s => s.classList.add('completed'));
            if (stepIndicator4) stepIndicator4.classList.add('completed');
            progressLine1.classList.add('active');
            progressLine2.classList.add('active');
            if (progressLine3) progressLine3.classList.add('active');
        }
    }
    
    // ============ Event Listeners - Navigation ============
    btnStartRegister.addEventListener('click', () => {
        showView(registerView);
        showStep(1);
    });
    
    btnCheckResults.addEventListener('click', () => showView(resultsView));
    btnInstructions.addEventListener('click', () => showView(instructionsView));
    
    navHome.addEventListener('click', (e) => { 
        e.preventDefault(); 
        navigationHistory = [];
        showView(landingView, false); 
    });
    navResults.addEventListener('click', (e) => { e.preventDefault(); showView(resultsView); });
    
    // Back buttons - use goBack for proper navigation
    btnBackLanding.addEventListener('click', () => goBack());
    btnBackResults.addEventListener('click', () => goBack());
    btnBackInstructions.addEventListener('click', () => goBack());
    
    // Start registration from instructions page
    btnStartFromInstructions.addEventListener('click', () => {
        showView(registerView);
        showStep(1);
    });
    
    // ============ Form Data Retention (SessionStorage) ============
    const FORM_STORAGE_KEY = 'hackathon_registration_form';
    
    function saveFormData() {
        const formData = {
            fullName: fullNameInput.value,
            mobile: mobileInput.value,
            branch: branchInput.value,
            collegeName: collegeNameInput.value,
            city: cityInput.value,
            rollNumber: rollNumberInput.value,
            githubProfile: githubProfileInput ? githubProfileInput.value : '',
            projectSelected: projectSelectedInput.value,
            participationMode: document.querySelector('input[name="participationMode"]:checked')?.value || '',
            teamName: teamNameInput?.value || ''
        };
        
        // Save all team member data (1-4)
        for (let i = 1; i <= MAX_TEAM_MEMBERS; i++) {
            formData[`member${i}Name`] = document.getElementById(`member${i}-name`)?.value || '';
            formData[`member${i}Email`] = document.getElementById(`member${i}-email`)?.value || '';
            formData[`member${i}Mobile`] = document.getElementById(`member${i}-mobile`)?.value || '';
            formData[`member${i}Roll`] = document.getElementById(`member${i}-roll`)?.value || '';
            formData[`member${i}Github`] = document.getElementById(`member${i}-github`)?.value || '';
        }
        
        sessionStorage.setItem(FORM_STORAGE_KEY, JSON.stringify(formData));
    }
    
    function loadFormData() {
        const savedData = sessionStorage.getItem(FORM_STORAGE_KEY);
        if (!savedData) return;
        
        try {
            const formData = JSON.parse(savedData);
            
            if (formData.fullName) fullNameInput.value = formData.fullName;
            if (formData.mobile) mobileInput.value = formData.mobile;
            if (formData.branch) branchInput.value = formData.branch;
            if (formData.collegeName) collegeNameInput.value = formData.collegeName;
            if (formData.city) cityInput.value = formData.city;
            if (formData.rollNumber) rollNumberInput.value = formData.rollNumber;
            if (formData.githubProfile && githubProfileInput) githubProfileInput.value = formData.githubProfile;
            if (formData.projectSelected) projectSelectedInput.value = formData.projectSelected;
            
            if (formData.participationMode) {
                const modeInput = document.querySelector(`input[name="participationMode"][value="${formData.participationMode}"]`);
                if (modeInput) modeInput.checked = true;
            }
            
            if (formData.teamName && teamNameInput) teamNameInput.value = formData.teamName;
            
            // Load team member data (1-4)
            for (let i = 1; i <= MAX_TEAM_MEMBERS; i++) {
                const nameEl = document.getElementById(`member${i}-name`);
                const emailEl = document.getElementById(`member${i}-email`);
                const mobileEl = document.getElementById(`member${i}-mobile`);
                const rollEl = document.getElementById(`member${i}-roll`);
                const githubEl = document.getElementById(`member${i}-github`);
                
                if (formData[`member${i}Name`] && nameEl) nameEl.value = formData[`member${i}Name`];
                if (formData[`member${i}Email`] && emailEl) emailEl.value = formData[`member${i}Email`];
                if (formData[`member${i}Mobile`] && mobileEl) mobileEl.value = formData[`member${i}Mobile`];
                if (formData[`member${i}Roll`] && rollEl) rollEl.value = formData[`member${i}Roll`];
                if (formData[`member${i}Github`] && githubEl) githubEl.value = formData[`member${i}Github`];
            }
        } catch (e) {
            console.error('Error loading form data:', e);
        }
    }
    
    function clearFormData() {
        sessionStorage.removeItem(FORM_STORAGE_KEY);
    }
    
    // Auto-save form data on input
    const formInputs = [fullNameInput, mobileInput, branchInput, collegeNameInput, cityInput, rollNumberInput, githubProfileInput, projectSelectedInput, teamNameInput];
    formInputs.forEach(input => {
        if (input) {
            input.addEventListener('input', saveFormData);
            input.addEventListener('change', saveFormData);
        }
    });
    
    // Save participation mode changes
    participationModeInputs.forEach(input => {
        input.addEventListener('change', saveFormData);
    });
    
    // Save team member data - dynamic for all 4 members
    for (let i = 1; i <= MAX_TEAM_MEMBERS; i++) {
        ['name', 'email', 'mobile', 'roll', 'github'].forEach(field => {
            const el = document.getElementById(`member${i}-${field}`);
            if (el) {
                el.addEventListener('input', saveFormData);
            }
        });
    }
    
    // ============ Load Colleges Dynamically ============
    async function loadColleges() {
        const collegeLoading = document.getElementById('college-loading');
        if (collegeLoading) collegeLoading.style.display = 'block';
        
        try {
            const res = await fetch('/api/colleges');
            const data = await res.json();
            
            // Clear existing options except the default
            while (collegeNameInput.options.length > 1) {
                collegeNameInput.remove(1);
            }
            
            // Add colleges from database
            data.colleges.forEach(college => {
                const option = document.createElement('option');
                option.value = college.name;
                option.textContent = college.name;
                if (college.city) {
                    option.textContent += ` (${college.city})`;
                }
                collegeNameInput.appendChild(option);
            });
            
            collegesLoaded = true;
            if (collegeLoading) collegeLoading.style.display = 'none';
        } catch (err) {
            console.error('Error loading colleges:', err);
            if (collegeLoading) {
                collegeLoading.style.display = 'none';
                collegeLoading.innerHTML = '<i class="fas fa-exclamation-circle"></i> Failed to load colleges';
                collegeLoading.style.display = 'block';
                collegeLoading.style.color = 'var(--error)';
            }
        }
    }
    
    // Load colleges on page load
    loadColleges();
    
    // ============ Duplicate Checking Functions ============
    async function checkDuplicate(field, value) {
        if (!value || value.trim() === '') return { exists: false };
        
        try {
            let endpoint = '';
            if (field === 'rollNumber') {
                endpoint = `/api/check-roll-number/${encodeURIComponent(value)}`;
            } else if (field === 'githubProfile') {
                endpoint = `/api/check-github/${encodeURIComponent(value)}`;
            } else if (field === 'email') {
                endpoint = `/api/check-email/${encodeURIComponent(value)}`;
            }
            
            const res = await fetch(endpoint);
            return await res.json();
        } catch (err) {
            console.error('Error checking duplicate:', err);
            return { exists: false };
        }
    }
    
    // Real-time duplicate checking for roll number
    let rollNumberTimeout;
    rollNumberInput.addEventListener('input', () => {
        clearTimeout(rollNumberTimeout);
        const errorEl = document.getElementById('error-rollNumber');
        
        rollNumberTimeout = setTimeout(async () => {
            if (rollNumberInput.value.trim()) {
                const result = await checkDuplicate('rollNumber', rollNumberInput.value.trim());
                if (result.exists) {
                    errorEl.textContent = result.message || 'Already exists.';
                    errorEl.style.color = 'var(--error)';
                } else {
                    errorEl.textContent = '';
                }
            }
        }, 500);
    });
    
    // Real-time duplicate checking for GitHub profile
    let githubTimeout;
    if (githubProfileInput) {
        githubProfileInput.addEventListener('input', () => {
            clearTimeout(githubTimeout);
            const errorEl = document.getElementById('error-githubProfile');
            
            githubTimeout = setTimeout(async () => {
                if (githubProfileInput.value.trim()) {
                    const result = await checkDuplicate('githubProfile', githubProfileInput.value.trim());
                    if (result.exists) {
                        errorEl.textContent = result.message || 'Already exists.';
                        errorEl.style.color = 'var(--error)';
                    } else {
                        errorEl.textContent = '';
                    }
                }
            }, 500);
        });
    }
    
    // ============ Google OAuth ============
    btnGoogleAuth.addEventListener('click', async (e) => {
        e.preventDefault();
        
        btnGoogleAuth.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Connecting...';
        btnGoogleAuth.disabled = true;
        authError.classList.add('hidden');
        alreadyRegistered.classList.add('hidden');
        
        // Open OAuth popup
        const width = 500, height = 600;
        const left = (window.screen.width / 2) - (width / 2);
        const top = (window.screen.height / 2) - (height / 2);
        
        const authWindow = window.open(
            '/api/auth/login',
            'Google Auth',
            `width=${width},height=${height},top=${top},left=${left}`
        );
        
        // Poll for window close
        const checkClosed = setInterval(() => {
            if (authWindow.closed) {
                clearInterval(checkClosed);
                if (!currentUser.email) {
                    btnGoogleAuth.innerHTML = '<i class="fab fa-google"></i> Continue with Google';
                    btnGoogleAuth.disabled = false;
                }
            }
        }, 1000);
        
        // Listen for message from popup
        window.addEventListener('message', handleAuthMessage, false);
    });
    
    function handleAuthMessage(event) {
        if (event.origin !== window.location.origin) return;
        
        const data = event.data;
        
        if (data.status === 'success') {
            if (data.alreadyRegistered) {
                alreadyRegistered.classList.remove('hidden');
                btnGoogleAuth.innerHTML = '<i class="fab fa-google"></i> Continue with Google';
                btnGoogleAuth.disabled = false;
                return;
            }
            
            currentUser.email = data.email;
            currentUser.name = data.name || '';
            currentUser.googleId = data.google_id;
            
            transitionToStep2();
        } else if (data.status === 'failed') {
            document.getElementById('auth-error-text').textContent = data.error || 'Authentication failed.';
            authError.classList.remove('hidden');
            btnGoogleAuth.innerHTML = '<i class="fab fa-google"></i> Continue with Google';
            btnGoogleAuth.disabled = false;
        }
        
        window.removeEventListener('message', handleAuthMessage);
    }
    
    async function transitionToStep2() {
        // Pre-fill data
        emailInput.value = currentUser.email;
        if (!fullNameInput.value) {
            fullNameInput.value = currentUser.name;
        }
        registrationDateInput.value = new Date().toLocaleString();
        
        // Set placeholder - actual ID will be generated after payment
        currentUser.participantId = '';
        participantIdInput.value = 'Generated after payment';
        participantIdInput.style.fontStyle = 'italic';
        participantIdInput.style.color = '#666';
        
        // Load any previously saved form data
        loadFormData();
        
        showStep(2);
    }
    
    // ============ Form Validation ============
    function validateField(input, errorId, regex = null, customMsg = '') {
        const errorEl = document.getElementById(errorId);
        if (!errorEl) return true;
        
        const value = input.value.trim();
        
        if (!value) {
            errorEl.textContent = 'This field is required';
            return false;
        }
        
        if (regex && !regex.test(value)) {
            errorEl.textContent = customMsg || 'Invalid format';
            return false;
        }
        
        errorEl.textContent = '';
        return true;
    }
    
    // Real-time validation
    mobileInput.addEventListener('input', () => {
        mobileInput.value = mobileInput.value.replace(/[^0-9]/g, '');
        validateField(mobileInput, 'error-mobile', /^[0-9]{10}$/, 'Enter a valid 10-digit number');
    });
    
    // ============ Registration Form Submit ============
    registrationForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        let isValid = true;
        
        if (!validateField(fullNameInput, 'error-fullName')) isValid = false;
        if (!validateField(mobileInput, 'error-mobile', /^[0-9]{10}$/, 'Enter a valid 10-digit number')) isValid = false;
        if (!validateField(branchInput, 'error-branch')) isValid = false;
        if (!validateField(collegeNameInput, 'error-collegeName')) isValid = false;
        if (!validateField(cityInput, 'error-city')) isValid = false;
        if (!validateField(rollNumberInput, 'error-rollNumber')) isValid = false;
        if (!validateField(githubProfileInput, 'error-githubProfile', /^https:\/\/www\.github\.com\/.+$/, 'GitHub URL must start with https://www.github.com/')) isValid = false;
        if (!validateField(projectSelectedInput, 'error-projectSelected')) isValid = false;
        
        // Check participation mode
        const participationMode = document.querySelector('input[name="participationMode"]:checked');
        if (!participationMode) {
            document.getElementById('error-participationMode').textContent = 'Please select a participation mode';
            isValid = false;
        } else {
            document.getElementById('error-participationMode').textContent = '';
        }
        
        // Check for duplicates before submitting
        if (isValid) {
            const rollResult = await checkDuplicate('rollNumber', rollNumberInput.value.trim());
            if (rollResult.exists) {
                document.getElementById('error-rollNumber').textContent = rollResult.message || 'Already exists.';
                isValid = false;
            }
            
            const githubResult = await checkDuplicate('githubProfile', githubProfileInput.value.trim());
            if (githubResult.exists) {
                document.getElementById('error-githubProfile').textContent = githubResult.message || 'Already exists.';
                isValid = false;
            }
        }
        
        if (!isValid) return;
        
        // Save form data before proceeding
        saveFormData();
        
        // If Team mode, go to step 3
        if (participationMode.value === 'team') {
            await setupTeamStep();
            showStep(3);
        } else {
            // Individual - go to Payment step (Step 4)
            updatePaymentSummary();
            showStep(4);
        }
    });
    
    // ============ Team Step ============
    async function setupTeamStep() {
        ensureMemberCards();

        // Set placeholder - actual team ID will be generated after payment
        teamIdInput.value = 'Generated after payment';
        currentUser.participantId = '';
        participantIdInput.value = 'Generated after payment';
        participantIdInput.style.fontStyle = 'italic';
        participantIdInput.style.color = '#666';
        
        // Show leader info
        leaderInfoEl.textContent = `${fullNameInput.value} (${emailInput.value})`;
        
        // Show college and branch info (inherited by all members)
        if (leaderCollegeInfoEl) {
            const collegeName = collegeNameInput.value;
            const branchName = branchInput.options[branchInput.selectedIndex]?.text || branchInput.value;
            const taskName = projectSelectedInput.options[projectSelectedInput.selectedIndex]?.text || projectSelectedInput.value;
            leaderCollegeInfoEl.innerHTML = `<i class="fas fa-university"></i> ${collegeName} | <i class="fas fa-code-branch"></i> ${branchName} | <i class="fas fa-tasks"></i> ${taskName}`;
        }

        await lockLeaderFieldsForMemberForms();
        
        // Reset member cards - show only first one
        for (let i = 1; i <= MAX_TEAM_MEMBERS; i++) {
            const card = document.getElementById(`member-${i}-card`);
            if (card) {
                if (i === 1) {
                    card.classList.remove('hidden');
                } else {
                    card.classList.add('hidden');
                    clearMemberCard(i);
                }
            }
        }
        
        teamMemberCount = 1;
        updateAddMemberButton();
    }

    function ensureMemberCards() {
        const container = document.getElementById('team-members-container');
        if (!container) return;

        for (let i = 1; i <= MAX_TEAM_MEMBERS; i++) {
            if (document.getElementById(`member-${i}-card`)) continue;

            const card = document.createElement('div');
            card.className = i === 1 ? 'team-member-card' : 'team-member-card hidden';
            card.id = `member-${i}-card`;
            card.innerHTML = `
                <div class="member-header">
                    <span>Member ${i}</span>
                    <button type="button" class="btn-remove-member" data-member="${i}">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Full Name *</label>
                        <input type="text" id="member${i}-name" placeholder="Member name">
                    </div>
                    <div class="form-group">
                        <label>Email *</label>
                        <input type="email" id="member${i}-email" placeholder="Member email">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Mobile *</label>
                        <input type="tel" id="member${i}-mobile" maxlength="10" placeholder="10-digit number">
                    </div>
                    <div class="form-group">
                        <label>Roll Number *</label>
                        <input type="text" id="member${i}-roll" placeholder="Roll number">
                    </div>
                </div>
                <div class="form-group">
                    <label>GitHub Profile *</label>
                    <input type="url" id="member${i}-github" placeholder="https://www.github.com/username">
                </div>
                <div class="inherited-team-fields form-row">
                    <div class="form-group">
                        <label>College Name (Leader)</label>
                        <input type="text" class="member-college readonly-input" readonly>
                    </div>
                    <div class="form-group">
                        <label>Branch (Leader)</label>
                        <input type="text" class="member-branch readonly-input" readonly>
                    </div>
                </div>
                <div class="form-group inherited-team-fields">
                    <label>Task (Leader)</label>
                    <input type="text" class="member-task readonly-input" readonly>
                </div>
                <p class="member-inherited-hint helper-text"></p>
            `;
            container.appendChild(card);
        }

        document.querySelectorAll('.btn-remove-member').forEach(btn => {
            btn.onclick = () => {
                const memberNum = parseInt(btn.dataset.member, 10);
                removeMember(memberNum);
            };
        });
    }

    async function lockLeaderFieldsForMemberForms() {
        let leaderData = {
            collegeName: collegeNameInput.value,
            branch: branchInput.value,
            projectSelected: projectSelectedInput.value
        };

        // Only fetch from API if we have a real team ID (not placeholder)
        if (teamIdInput.value && teamIdInput.value.startsWith('SPX_HACK2026_TEAM_')) {
            try {
                const response = await fetch(`/api/team/${encodeURIComponent(teamIdInput.value)}/leader-details`);
                if (response.ok) {
                    const data = await response.json();
                    leaderData = {
                        collegeName: data.collegeName,
                        branch: data.branch,
                        projectSelected: data.projectSelected
                    };
                }
            } catch (err) {
                console.warn('Leader details API unavailable, using leader form values.');
            }
        }

        for (let i = 1; i <= MAX_TEAM_MEMBERS; i++) {
            const card = document.getElementById(`member-${i}-card`);
            if (!card) continue;

            ensureInheritedFields(card);

            const collegeField = card.querySelector('.member-college');
            const branchField = card.querySelector('.member-branch');
            const taskField = card.querySelector('.member-task');
            if (collegeField) {
                collegeField.value = leaderData.collegeName;
                collegeField.disabled = true;
            }
            if (branchField) {
                branchField.value = leaderData.branch;
                branchField.disabled = true;
            }
            if (taskField) {
                taskField.value = leaderData.projectSelected;
                taskField.disabled = true;
            }

            const inheritedHint = card.querySelector('.member-inherited-hint');
            if (inheritedHint) {
                inheritedHint.textContent = `College: ${leaderData.collegeName} | Branch: ${leaderData.branch} | Task: ${leaderData.projectSelected}`;
            }
        }
    }

    function ensureInheritedFields(card) {
        if (card.querySelector('.member-college') && card.querySelector('.member-branch') && card.querySelector('.member-task')) {
            return;
        }

        const inheritedWrapper = document.createElement('div');
        inheritedWrapper.innerHTML = `
            <div class="inherited-team-fields form-row">
                <div class="form-group">
                    <label>College Name (Leader)</label>
                    <input type="text" class="member-college readonly-input" readonly>
                </div>
                <div class="form-group">
                    <label>Branch (Leader)</label>
                    <input type="text" class="member-branch readonly-input" readonly>
                </div>
            </div>
            <div class="form-group inherited-team-fields">
                <label>Task (Leader)</label>
                <input type="text" class="member-task readonly-input" readonly>
            </div>
            <p class="member-inherited-hint helper-text"></p>
        `;
        card.appendChild(inheritedWrapper);
    }
    
    function updateAddMemberButton() {
        if (teamMemberCount >= MAX_TEAM_MEMBERS) {
            btnAddMember.style.display = 'none';
            if (memberLimitMsg) memberLimitMsg.classList.remove('hidden');
        } else {
            btnAddMember.style.display = 'inline-flex';
            if (memberLimitMsg) memberLimitMsg.classList.add('hidden');
        }
    }
    
    btnAddMember.addEventListener('click', () => {
        if (teamMemberCount < MAX_TEAM_MEMBERS) {
            teamMemberCount++;
            const card = document.getElementById(`member-${teamMemberCount}-card`);
            if (card) {
                card.classList.remove('hidden');
            }
            updateAddMemberButton();
            saveFormData();
        }
    });
    
    // Remove member buttons
    document.querySelectorAll('.btn-remove-member').forEach(btn => {
        btn.addEventListener('click', () => {
            const memberNum = parseInt(btn.dataset.member);
            removeMember(memberNum);
        });
    });
    
    function removeMember(memberNum) {
        // Shift all members up
        for (let i = memberNum; i < MAX_TEAM_MEMBERS; i++) {
            const nextCard = document.getElementById(`member-${i + 1}-card`);
            if (nextCard && !nextCard.classList.contains('hidden')) {
                // Copy next member data to current
                copyMemberData(i + 1, i);
            } else {
                // Clear current card
                clearMemberCard(i);
                break;
            }
        }
        
        // Hide the last visible card
        const lastCard = document.getElementById(`member-${teamMemberCount}-card`);
        if (lastCard) {
            lastCard.classList.add('hidden');
            clearMemberCard(teamMemberCount);
        }
        
        if (teamMemberCount > 1) {
            teamMemberCount--;
        }
        
        updateAddMemberButton();
        saveFormData();
    }
    
    function copyMemberData(fromNum, toNum) {
        const fields = ['name', 'email', 'mobile', 'roll', 'github'];
        fields.forEach(field => {
            const fromEl = document.getElementById(`member${fromNum}-${field}`);
            const toEl = document.getElementById(`member${toNum}-${field}`);
            if (fromEl && toEl) {
                toEl.value = fromEl.value;
            }
        });
    }
    
    function clearMemberCard(num) {
        const fields = ['name', 'email', 'mobile', 'roll', 'github'];
        fields.forEach(field => {
            const el = document.getElementById(`member${num}-${field}`);
            if (el) el.value = '';
        });
    }
    
    // Step 3 -> Step 4
    if (btnNextPayment) {
        btnNextPayment.addEventListener('click', async () => {
            // Validate team name
            if (!teamNameInput.value.trim()) {
                document.getElementById('error-teamName').textContent = 'Team name is required';
                return;
            }
            document.getElementById('error-teamName').textContent = '';
            
            // Validate at least one member
            const m1Name = document.getElementById('member1-name').value.trim();
            if (!m1Name) {
                alert('Please add at least one team member');
                return;
            }
            
            // Validate all visible members have required fields
            for (let i = 1; i <= teamMemberCount; i++) {
                const name = document.getElementById(`member${i}-name`).value.trim();
                const email = document.getElementById(`member${i}-email`).value.trim();
                const mobile = document.getElementById(`member${i}-mobile`).value.trim();
                const roll = document.getElementById(`member${i}-roll`).value.trim();
                const github = document.getElementById(`member${i}-github`).value.trim();
                
                if (!name || !email || !mobile || !roll || !github) {
                    alert(`Please fill all required fields for Member ${i}`);
                    return;
                }
                
                // Validate mobile format
                if (!/^\d{10}$/.test(mobile)) {
                    alert(`Invalid mobile number for Member ${i}. Please enter 10 digits.`);
                    return;
                }
                
                // Validate email format
                if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                    alert(`Invalid email format for Member ${i}`);
                    return;
                }
                
                // Validate GitHub URL format
                if (!/^https:\/\/www\.github\.com\/.+$/.test(github)) {
                    alert(`Invalid GitHub profile URL for Member ${i}. Please use format: https://www.github.com/username`);
                    return;
                }
                
                // Check for duplicate roll number
                const rollResult = await checkDuplicate('rollNumber', roll);
                if (rollResult.exists) {
                    alert(`Already exists.`);
                    return;
                }
                
                // Check for duplicate GitHub profile
                const githubResult = await checkDuplicate('githubProfile', github);
                if (githubResult.exists) {
                    alert(`Already exists.`);
                    return;
                }
                
                // Check for duplicate email
                const emailResult = await checkDuplicate('email', email);
                if (emailResult.exists) {
                    alert(`Email ${email} is already registered.`);
                    return;
                }
            }
            
            updatePaymentSummary();
            showStep(4);
        });
    }

    // ============ Payment Logic ============
    function updatePaymentSummary() {
        const participationMode = document.querySelector('input[name="participationMode"]:checked').value;
        const summaryMode = document.getElementById('summary-mode');
        const summaryTeamRow = document.getElementById('summary-team-row');
        const summaryTeamSize = document.getElementById('summary-team-size');
        const summaryAmount = document.getElementById('summary-amount');
        
        let amount = 20;
        
        if (participationMode === 'team') {
            summaryMode.textContent = 'Team';
            summaryTeamRow.classList.remove('hidden');
            // Leader + members
            const totalMembers = 1 + teamMemberCount;
            summaryTeamSize.textContent = totalMembers;
            amount = 20 * totalMembers;
        } else {
            summaryMode.textContent = 'Individual';
            summaryTeamRow.classList.add('hidden');
            amount = 20;
        }
        
        summaryAmount.textContent = `₹${amount}`;
    }

    if (btnPayNow) {
        btnPayNow.addEventListener('click', async () => {
            const originalText = btnPayNow.innerHTML;
            btnPayNow.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
            btnPayNow.disabled = true;
            
            try {
                // Create Order
                const participationMode = document.querySelector('input[name="participationMode"]:checked').value;
                const orderRequest = {
                    participationMode: participationMode,
                    teamMembersCount: participationMode === 'team' ? teamMemberCount : 0,
                    email: currentUser.email,
                    fullName: fullNameInput.value,
                    mobile: mobileInput.value
                };
                
                const res = await fetch('/api/payment/order', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(orderRequest)
                });

                const data = await res.json();
                if (!res.ok) {
                    throw new Error(data.detail || 'Failed to create payment order');
                }

                if (data.mockMode) {
                    const verifyRes = await fetch('/api/payment/verify', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            cf_order_id: data.orderId,
                            cf_payment_id: data.mockPaymentId || null
                        })
                    });

                    const verifyData = await verifyRes.json();
                    if (!verifyRes.ok) {
                        throw new Error(verifyData.detail || 'Mock payment verification failed');
                    }

                    currentPayment = {
                        orderId: verifyData.cf_order_id || data.orderId,
                        paymentId: verifyData.cf_payment_id || data.mockPaymentId || '',
                        gateway: 'cashfree',
                        amount: data.amount
                    };

                    document.getElementById('payment-success-msg').classList.remove('hidden');
                    document.getElementById('display-transaction-id').textContent = currentPayment.paymentId || currentPayment.orderId;
                    document.querySelector('.payment-method').classList.add('hidden');
                    btnSubmitFinal.classList.remove('hidden');
                    if (data.message) {
                        alert(data.message);
                    }
                    return;
                }


                // Open Cashfree Checkout
                if (typeof Cashfree === 'undefined') {
                    throw new Error('Cashfree SDK failed to load');
                }

                const cashfree = Cashfree({ mode: (data.environment || 'sandbox').toLowerCase() });
                const checkoutResult = await cashfree.checkout({
                    paymentSessionId: data.paymentSessionId,
                    redirectTarget: '_modal'
                });

                if (checkoutResult && checkoutResult.error) {
                    throw new Error(checkoutResult.error.message || 'Payment failed');
                }

                btnPayNow.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Verifying...';
                btnPayNow.disabled = true;

                const paymentDetails = (checkoutResult && checkoutResult.paymentDetails) || {};
                const cfPaymentId = paymentDetails.paymentId || paymentDetails.cf_payment_id || '';

                const verifyRes = await fetch('/api/payment/verify', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        cf_order_id: data.orderId,
                        cf_payment_id: cfPaymentId || null
                    })
                });

                const verifyData = await verifyRes.json();
                if (!verifyRes.ok) {
                    throw new Error(verifyData.detail || 'Payment verification failed on server');
                }

                currentPayment = {
                    orderId: verifyData.cf_order_id || data.orderId,
                    paymentId: verifyData.cf_payment_id || cfPaymentId,
                    gateway: 'cashfree',
                    amount: data.amount
                };

                // Show success message and complete registration button
                document.getElementById('payment-success-msg').classList.remove('hidden');
                document.getElementById('display-transaction-id').textContent = currentPayment.paymentId || currentPayment.orderId;
                document.querySelector('.payment-method').classList.add('hidden');
                btnSubmitFinal.classList.remove('hidden');
                
            } catch (err) {
                console.error(err);
                alert(err.message || 'Error processing payment. Please try again.');
            } finally {
                btnPayNow.innerHTML = originalText;
                btnPayNow.disabled = false;
            }
        });
    }

    if (btnSubmitFinal) {
        btnSubmitFinal.addEventListener('click', async () => {
             const participationMode = document.querySelector('input[name="participationMode"]:checked').value;
             await submitRegistration(participationMode === 'team');
        });
    }

    if (btnBackStep3) {
        btnBackStep3.addEventListener('click', () => {
             const participationMode = document.querySelector('input[name="participationMode"]:checked').value;
             if (participationMode === 'team') {
                 showStep(3);
             } else {
                 showStep(2);
             }
        });
    }
    
    // ============ Submit Registration ============
    function formatApiError(detail) {
        if (!detail) return 'Unknown error';
        if (typeof detail === 'string') return detail;
        if (Array.isArray(detail)) {
            return detail
                .map((item) => {
                    if (typeof item === 'string') return item;
                    const path = Array.isArray(item.loc) ? item.loc.join('.') : '';
                    const msg = item.msg || JSON.stringify(item);
                    return path ? `${path}: ${msg}` : msg;
                })
                .join('; ');
        }
        if (typeof detail === 'object') {
            return detail.message || JSON.stringify(detail);
        }
        return String(detail);
    }

    async function submitRegistration(isTeam) {
        const btn = btnSubmitFinal; // Using btnSubmitFinal now
        const originalText = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';
        btn.disabled = true;
        
        const participationMode = document.querySelector('input[name="participationMode"]:checked').value;
        
        const userData = {
            // participantId will be generated by backend after payment verification
            fullName: fullNameInput.value.trim(),
            email: currentUser.email,
            mobile: mobileInput.value.trim(),
            branch: branchInput.value,
            collegeName: collegeNameInput.value.trim(),
            city: cityInput.value.trim(),
            rollNumber: rollNumberInput.value.trim(),
            githubProfile: githubProfileInput.value.trim(),
            projectSelected: projectSelectedInput.value,
            participationMode: participationMode,
            isTeamLeader: isTeam
        };

        // Add Payment Details
        if (currentPayment.orderId) {
            userData.payment_gateway = currentPayment.gateway;
            userData.cf_payment_id = currentPayment.paymentId;
            userData.cf_order_id = currentPayment.orderId;
            userData.payment_amount = currentPayment.amount;
        }
        
        if (isTeam) {
            // teamId will be generated by backend after payment verification
            userData.teamName = teamNameInput.value.trim();
            userData.teamMembers = [];
            
            // Collect all visible team members
            for (let i = 1; i <= teamMemberCount; i++) {
                const member = {
                    fullName: document.getElementById(`member${i}-name`).value.trim(),
                    email: document.getElementById(`member${i}-email`).value.trim(),
                    mobile: document.getElementById(`member${i}-mobile`).value.trim(),
                    rollNumber: document.getElementById(`member${i}-roll`).value.trim(),
                    githubProfile: document.getElementById(`member${i}-github`).value.trim()
                    // Note: college and branch will be inherited from leader on backend
                };
                if (member.fullName) {
                    userData.teamMembers.push(member);
                }
            }
        }
        
        try {
            const response = await fetch('/api/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(userData)
            });
            
            const result = await response.json();
            
            if (response.ok) {
                showSuccess(result, userData);
            } else {
                alert('Registration Failed: ' + formatApiError(result.detail));
                btn.innerHTML = originalText;
                btn.disabled = false;
            }
        } catch (err) {
            console.error('Error:', err);
            alert('Network error. Please try again.');
            btn.innerHTML = originalText;
            btn.disabled = false;
        }
    }
    
    function showSuccess(apiResult, userData) {
        console.log('API Result:', apiResult);
        console.log('User Data:', userData);
        
        // Display the actual participant ID returned from backend after payment
        const actualId = apiResult.participantId || 'N/A';
        document.getElementById('summary-id').textContent = actualId;
        document.getElementById('summary-name').textContent = apiResult.fullName || userData.fullName;
        document.getElementById('summary-email').textContent = apiResult.email || userData.email;
        document.getElementById('summary-project').textContent = userData.projectSelected;
        
        // Show team member IDs if team registration
        const teamMemberContainer = document.getElementById('team-members-summary');
        if (apiResult.teamMemberIds && apiResult.teamMemberIds.length > 0) {
            let memberHTML = '<div class="team-members-section"><h3>Team Member IDs:</h3><ul class="team-ids-list">';
            memberHTML += `<li><strong>Leader (${apiResult.fullName}):</strong> ${actualId}</li>`;
            
            apiResult.teamMemberIds.forEach((memberId, index) => {
                const memberName = userData.teamMembers && userData.teamMembers[index] ? userData.teamMembers[index].fullName : `Member ${index + 1}`;
                memberHTML += `<li><strong>${memberName}:</strong> ${memberId}</li>`;
            });
            
            memberHTML += '</ul></div>';
            teamMemberContainer.innerHTML = memberHTML;
            teamMemberContainer.classList.remove('hidden');
        } else {
            teamMemberContainer.innerHTML = '';
            teamMemberContainer.classList.add('hidden');
        }
        
        // Clear saved form data on successful registration
        clearFormData();
        
        showStep('success');
    }
    
    document.getElementById('btn-home').addEventListener('click', () => {
        // Clear navigation history and reload
        navigationHistory = [];
        window.location.reload();
    });
    
    // ============ Results Check ============
    resultsForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const email = document.getElementById('result-email').value.trim();
        if (!email) {
            document.getElementById('error-result-email').textContent = 'Email is required';
            return;
        }
        
        const btn = resultsForm.querySelector('button[type="submit"]');
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Checking...';
        btn.disabled = true;
        
        try {
            const response = await fetch('/api/check-result', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email })
            });
            
            const result = await response.json();
            
            if (response.ok) {
                displayResult(result);
            } else {
                document.getElementById('error-result-email').textContent = result.detail || 'Not found';
                document.getElementById('result-display').classList.add('hidden');
            }
        } catch (err) {
            document.getElementById('error-result-email').textContent = 'Error checking results';
        }
        
        btn.innerHTML = '<i class="fas fa-search"></i> Check Status';
        btn.disabled = false;
    });
    
    function displayResult(data) {
        document.getElementById('error-result-email').textContent = '';
        document.getElementById('result-display').classList.remove('hidden');
        
        const statusBadge = document.getElementById('result-status-badge');
        const resultCard = document.getElementById('result-card');
        
        // Set status
        statusBadge.textContent = data.status;
        statusBadge.className = 'result-status';
        
        if (data.status === 'Verified') {
            statusBadge.classList.add('selected');
        } else if (data.status === 'Not Verified') {
            statusBadge.classList.add('not-selected');
        } else {
            statusBadge.classList.add('pending');
        }
        
        // Fill details
        document.getElementById('result-name').textContent = data.fullName;
        document.getElementById('result-participant-id').textContent = data.participantId;
        document.getElementById('result-project').textContent = data.projectSelected;
        document.getElementById('result-mode').textContent = data.participationMode === 'team' ? 'Team' : 'Individual';
        
        if (data.teamName) {
            document.getElementById('result-team-name-row').classList.remove('hidden');
            document.getElementById('result-team-name').textContent = data.teamName;
        } else {
            document.getElementById('result-team-name-row').classList.add('hidden');
        }
        
    }
    
    // ============ Reload colleges when returning to step 2 ============
    btnBackStep2.addEventListener('click', () => {
        showStep(2);
        // Ensure colleges are loaded when going back
        if (!collegesLoaded) {
            loadColleges();
        }
    });
});
