# Spheronix Hackathon Registration System

FastAPI + MongoDB hackathon registration platform with Google OAuth, individual/team registration, Cashfree verification, and confirmation email support.

## Stack

- Python 3.x
- FastAPI
- MongoDB (Motor + PyMongo)
- HTML, CSS, JavaScript
- Cashfree Payments

## Registration Flow

1. Google OAuth login (`/api/auth/login`, `/api/auth/callback`)
2. Details submission (email auto-filled, unique checks)
3. Payment verification succeeds
4. Post-payment ID generation:
  - Individual: `SPX_HACK2026_INDV_XXXXXX` (6-digit numeric)
  - Team base: `SPX_HACK2026_TEAM_XXXXXX` (6-digit numeric)
  - Team members: `SPX_HACK2026_TEAM_XXXXXX_01` to `_05`
4. Payment verification and registration confirmation

## Team Rule Enforcement

When mode is team:

- Leader chooses `collegeName`, `branch`, and `projectSelected`.
- Frontend shows those values for members as read-only inherited values.
- Backend always overrides member payload values with leader values before saving.

## MongoDB Collections

- `users`
- `registrations`
- `teams`
- `payments`

Unique indexes include:

- `email`
- `mobile`
- `rollNumber`
- `participantId`

## Environment Variables

Set in `.env`:

```env
MONGO_URI=...
DB_NAME=spheronix_db

GOOGLE_CLIENT_ID=...
GOOGLE_CLIENT_SECRET=...
GOOGLE_REDIRECT_URI=http://127.0.0.1:8000/api/auth/callback

SECRET_KEY=...
JWT_SECRET=...

CASHFREE_APP_ID=...
CASHFREE_SECRET_KEY=...
CASHFREE_ENVIRONMENT=SANDBOX

SMTP_HOST=
SMTP_PORT=587
SMTP_USER=
SMTP_PASSWORD=
MAIL_FROM=
```

## Google OAuth Setup

In Google Cloud Console (OAuth client type: Web application):

- Authorized redirect URIs must include the exact redirect URI your app uses:
  - `http://127.0.0.1:8000/api/auth/callback`
  - `http://localhost:8000/api/auth/callback` (optional but recommended)
- If consent screen is in testing mode, add your account as a test user.

## Install and Run

```bash
python -m pip install -r requirements.txt
python main.py
```

Open: `http://127.0.0.1:8000`

## Important Endpoints

- `GET /api/auth/login`
- `GET /api/auth/callback`
- `GET /api/generate-id`
- `GET /api/generate-team-id`
- `GET /api/team/{team_id}/leader-details`
- `POST /api/payment/order`
- `POST /api/payment/verify`
- `POST /api/payment/success-callback`
- `POST /api/payment/webhook`
- `POST /api/register`
- `POST /api/check-result`

## Cashfree Payment Flow

1. Frontend calls `POST /api/payment/order` with participant context.
2. Backend creates a Cashfree order and returns:
  - `orderId`
  - `paymentSessionId`
  - `amount`, `currency`, `environment`
3. Frontend opens Cashfree checkout using the session ID.
4. Frontend calls `POST /api/payment/verify` with `cf_order_id` and optional `cf_payment_id`.
5. Backend verifies status from Cashfree API and marks payment as verified.
6. Frontend submits final registration to `POST /api/register` with Cashfree payment fields.

## Webhook Configuration (Cashfree)

Configure webhook in Cashfree Dashboard:

1. Go to your Cashfree app settings (sandbox/prod as needed).
2. Add webhook URL:
  - `https://<your-domain>/api/payment/webhook`
3. Enable payment/order events for status updates.
4. Ensure backend `CASHFREE_SECRET_KEY` matches the signing key context.
5. Validate delivery attempts in Cashfree webhook logs.

The webhook endpoint verifies `x-webhook-signature` before accepting payload updates.

## Cashfree Sandbox Testing

1. Set `.env`:
  - `CASHFREE_ENVIRONMENT=SANDBOX`
  - valid sandbox `CASHFREE_APP_ID` and `CASHFREE_SECRET_KEY`
2. Run app and complete registration till payment step.
3. Finish checkout using Cashfree sandbox test mode.
4. Confirm frontend shows payment success and transaction reference.
5. Verify API behavior:
  - `/api/payment/verify` returns success.
  - `/api/register` completes and returns participant ID.
6. Inspect MongoDB `payments` document for:
  - `payment_gateway: "cashfree"`
  - `cf_order_id`
  - `cf_payment_id`
  - `payment_status`
7. Send/observe a webhook event and confirm `/api/payment/webhook` updates the same payment record.

## Validation Rules

- Mobile: exactly 10 digits
- Email: unique
- Roll number: unique
- GitHub profile: must start with `https://www.github.com/`
- Participant IDs: generated securely and checked for uniqueness
